import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class StudentRegister extends JPanel implements KeyListener
{
	JLabel l1,l2,l3,l4;
	ButtonGroup bg;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8;
	JButton b1,b2;
	JRadioButton rb1,rb2;
	Font f=new Font("",Font.BOLD,55);
	StudentRegister(FDemo f1)
	{
		setLayout(null);
		setBackground(Color.BLACK);	
		bg=new ButtonGroup();
		
		l4=new JLabel("REGISTRATION");
		l4.setBounds(390,30,450,50);
		l4.setFont(f);
		l4.setForeground(Color.WHITE);
		add(l4);
		
		Font f=new Font("",Font.BOLD,25);
		tx1=new JTextField("First Name");
		tx1.setBounds(420,130,350,40);
		tx1.setForeground(Color.gray);
		tx1.setFont(f);
		add(tx1);
		
		tx2=new JTextField("Last Name");
		tx2.setBounds(420,190,350,40);
		tx2.setForeground(Color.gray);
		tx2.setFont(f);
		add(tx2);
		
		tx3=new JTextField("Email");
		tx3.setBounds(420,250,350,40);
		tx3.setForeground(Color.gray);
		tx3.setFont(f);
		add(tx3);
		
		tx4=new JTextField("Password");
		tx4.setForeground(Color.gray);
		tx4.setBounds(420,310,350,40);
		tx4.setFont(f);
		add(tx4);
		
		tx5=new JTextField("Confirm Password");
		tx5.setBounds(420,370,350,40);
		tx5.setForeground(Color.gray);
		tx5.setFont(f);
		add(tx5);
		
		tx6=new JTextField("DD/MM/YYYY");
		tx6.setBounds(420,430,350,40);
		tx6.setFont(f);
		tx6.setForeground(Color.gray);
		add(tx6);
		
		tx7=new JTextField("Mobile Number");
		tx7.setBounds(420,490,350,40);
		tx7.setFont(f);
		tx7.setForeground(Color.gray);
		add(tx7);
		
		tx8=new JTextField("City/state");
		tx8.setBounds(420,550,350,40);
		tx8.setFont(f);
		tx8.setForeground(Color.gray);
		add(tx8);
		
		rb1=new JRadioButton("Male");
		rb1.setBounds(420,630,150,40);
		bg.add(rb1);
		rb1.setFont(f);
		add(rb1);
		
		rb2=new JRadioButton("Female");
		rb2.setBounds(575,630,150,40);
		bg.add(rb2);
		rb2.setFont(f);
		add(rb2);
		
		b1=new JButton("Register");
		b1.setBounds(420,700,150,40);
		b1.setBackground(Color.GRAY);
		b1.setForeground(Color.white);
		b1.setFont(f);
		add(b1);
		
		b2=new JButton("Back");
		b2.setBounds(620,700,150,40);
		b2.setBackground(Color.GRAY);
		b2.setForeground(Color.white);
		b2.setFont(f);
		add(b2);
		
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		
		tx1.addKeyListener(this);
		tx2.addKeyListener(this);
		tx3.addKeyListener(this);
		tx4.addKeyListener(this);
		tx5.addKeyListener(this);
		tx6.addKeyListener(this);
		tx7.addKeyListener(this);
		tx8.addKeyListener(this);
		rb1.setForeground(Color.white);		
		rb1.setBackground(Color.GRAY);		
		rb2.setForeground(Color.white);		
		rb2.setBackground(Color.GRAY);		
		// b1.setBackground(new Color(134,181,223));		
		// b2.setBackground(new Color(134,181,223));		
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		// setBackground(new Color(174,190,232));
		setBackground(Color.WHITE);
		// setForeground(new Color(134,181,223));		
		setForeground(Color.GRAY);		
		g.fillRoundRect(300,20,600,800,50,50);
			
	}
	public void keyPressed(KeyEvent e)
	{
		if(e.getSource()==tx1)
		{
			String s1=tx1.getText();
			if(s1.equals("First Name"))
			{
				tx1.setText("");
				tx1.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx2)
		{
			String s1=tx2.getText();
			if(s1.equals("Last Name"))
			{
				tx2.setText("");
				tx2.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx3)
		{
			String s1=tx3.getText();
			if(s1.equals("Email"))
			{
				tx3.setText("");
				tx3.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx4)
		{
			String s1=tx4.getText();
			if(s1.equals("Password"))
			{
				tx4.setText("");
				tx4.setForeground(Color.BLACK);
			}
		}
		
		if(e.getSource()==tx5)
		{
			String s1=tx5.getText();
			if(s1.equals("Confirm Password"))
			{
				tx5.setText("");
				tx5.setForeground(Color.BLACK);
			}
		}
		
		if(e.getSource()==tx6)
		{
			String s1=tx6.getText();
			if(s1.equals("DD/MM/YYYY"))
			{
				tx6.setText("");
				tx6.setForeground(Color.BLACK);
			}
		}
		
		if(e.getSource()==tx7)
		{
			String s1=tx7.getText();
			if(s1.equals("Mobile Number"))
			{
				tx7.setText("");
				tx7.setForeground(Color.BLACK);
			}
		}
		
		if(e.getSource()==tx8)
		{
			String s1=tx8.getText();
			if(s1.equals("City/state"))
			{
				tx8.setText("");
				tx8.setForeground(Color.BLACK);
			}
		}
		
	}	
	public void keyReleased(KeyEvent e)
	{
		if(e.getSource()==tx1)
		{
			String s1=tx1.getText().trim();
			if(s1.equals(""))
			{
				tx1.setText("First Name");
				tx1.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx2)
		{
			String s1=tx2.getText().trim();
			if(s1.equals(""))
			{
				tx2.setText("Last Name");
				tx2.setForeground(Color.gray);
			}
		}
		if(e.getSource()==tx3)
		{
			String s1=tx3.getText().trim();
			if(s1.equals(""))
			{
				tx3.setText("Email");
				tx3.setForeground(Color.gray);
			}
		}
		if(e.getSource()==tx4)
		{
			String s1=tx4.getText().trim();
			if(s1.equals(""))
			{
				tx4.setText("Password");
				tx4.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx5)
		{
			String s1=tx5.getText().trim();
			if(s1.equals(""))
			{
				tx5.setText("Confirm Password");
				tx5.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx6)
		{
			String s1=tx6.getText().trim();
			if(s1.equals(""))
			{
				tx6.setText("DD/MM/YYYY");
				tx6.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx7)
		{
			String s1=tx7.getText().trim();
			if(s1.equals(""))
			{
				tx7.setText("Mobile Number");
				tx7.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx8)
		{
			String s1=tx8.getText().trim();
			if(s1.equals(""))
			{
				tx8.setText("City/state");
				tx8.setForeground(Color.gray);
			}
		}
	}	
	public void keyTyped(KeyEvent e){}	
}