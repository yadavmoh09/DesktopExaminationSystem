// set classpath=E:\test\mysql-connector-java-8.0.13.jar;.;%classpath%
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
class JPDemo extends JPanel implements ActionListener
{
	JTextArea tx1,tx2;
	ButtonGroup bg;
	// int h=0;
	JRadioButton rb1,rb2,rb3,rb4;
	JButton b1,b2,b3;
	JLabel l1,l2,l3;
	int z=1,h1=1,y=10,x=0,h=0;
	Timer t;
	Font f=new Font("",Font.BOLD,25);
	ImageIcon ii;
	String s1;
	Image i;
	JPDemo(FDemo f1)
	{
		setLayout(null);
		
		bg=new ButtonGroup();
		
		tx1=new JTextArea();
		tx1.setFont(f);
		// tx1.setForeground(Color.BLACK);
		// tx1.setBackground(Color.BLACK);
		// tx1.setEnables(false);
		tx1.setBounds(150,200,760,60);
		add(tx1);
		
		tx2=new JTextArea();
		tx2.setFont(f);
		tx2.setBounds(20,150,70,30);
		add(tx2);
		
		l2=new JLabel("Time");
		l2.setFont(f);
		l2.setBounds(20,120,200,20);
		add(l2);
		
		rb1=new JRadioButton("option1");
		bg.add(rb1);
		rb1.setFont(f);
		rb1.setBounds(150,300,200,50);
		add(rb1);
		
		rb2=new JRadioButton("option2");
		rb2.setFont(f);
		bg.add(rb2);
		rb2.setBounds(150,350,200,50);
		add(rb2);
		
		rb3=new JRadioButton("option3");
		rb3.setFont(f);
		bg.add(rb3);
		rb3.setBounds(150,400,200,50);
		add(rb3);
		
		rb4=new JRadioButton("option4");
		rb4.setBounds(150,450,200,50);
		rb4.setFont(f);
		bg.add(rb4);
		add(rb4);
		
		b1=new JButton("Next");
		b1.setFont(f);
		b1.setBounds(600,500,150,30);
		add(b1);
		
		b3=new JButton("Privious");
		b3.setFont(f);
		b3.setBounds(450,500,150,30);
		add(b3);
		
		b2=new JButton("Submit");
		b2.setFont(f);
		b2.setBounds(750,500,150,30);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		b3.addActionListener(f1);
		
		rb1.setBackground(new Color(134,181,223));
		rb2.setBackground(new Color(134,181,223));
		rb3.setBackground(new Color(134,181,223));
		rb4.setBackground(new Color(134,181,223));
		Timer t=new Timer(1000,this);
		t.start();
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(110,100,900,500,50,50);
		g.fillRoundRect(5,100,100,100,30,30);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		if(h==1)
		{
			if(z==1)
			{
				if(x>0)
				{
					tx2.setText(""+y+":"+x);
				}
				else
				{
					x=60;y--;
				}
				--x;
			}
			if(y==-1)
			{
				z=0;
				tx2.setText(""+"0:0");
				y=-2;
			}
		}		
	}
}
class FDemo extends JFrame implements ActionListener,ItemListener
{
	int ch;
	String stu;
	String selectsubject;
	String selectsubject2;
	String aq[]=new String[1];
	AdminAddSubject aas;	
	StartExam se;
	JPDemo jp;
	StartDemo str;
	LoginDemo ld;
	HomeDemo hd;
	AdminLoginDemo ald;
	AdminMenu am;
	AdminAddQuestion aaq;
	AdminUpdateQuestion auq;
	AdminDeleteQuestion adq;
	AdminStudentProfile asp;
	AdminLogout al;
	StudentRegister sr;
	StudentLogin sl;
	StudentMenu sm;
	IntroPanel ip;	
	
	int xx=1,yy=1,in=0,sa=0;
	String coll[]=new String[10];
	int set=0,pset=0,hset=0,onetime=1;
	static int count=1;
	int y=1,result=0,n=1,ll=1,v=0;
	int x=3,y1=1,z=1;
	static int h=0;

	Container cn=getContentPane();
	CardLayout cr;
	ResultDemo rd;
	JButton b1;
	int i=0;
	static int xxx=0;
	
	int javashow=0;
	int phpshow=0;
	int htmlshow=0;
	FDemo(int x){}
	FDemo()
	{
		cr=new CardLayout();
		setLayout(cr);
			
			// ip=new IntroPanel(this);
			// add("intro",ip);
			
			hd=new HomeDemo(this);
			cn.add("home",hd);

			ald=new AdminLoginDemo(this);
			cn.add("adminlogin",ald);
		
			am=new AdminMenu(this);
			cn.add("adminmenu",am);
			
			sr=new StudentRegister(this);
			cn.add("sregister",sr);
			
			sl=new StudentLogin(this);
			cn.add("sLogin",sl);
			
			sm=new StudentMenu(this);
			cn.add("studentmenu",sm);	
			
			jp=new JPDemo(this);
			cn.add("jpd",jp);
			
			rd=new ResultDemo(this);
			cn.add("result",rd);
			
			aas=new AdminAddSubject(this);
			cn.add("addsubject",aas);
			
			se=new StartExam(this);
			cn.add("startexam",se);
			
	}
	
	public void actionPerformed(ActionEvent e)
	{
		// if(e.getSource()==ip.b1)
		// {
			// cr.show(cn,"home");
		// }
		if(e.getSource()==am.aas.b1)
		{
			String s1=am.aas.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				Statement st3=con.createStatement();
				
					String q="insert into sub values('"+s1+"')";
					st1.executeUpdate(q);
					am.aaq.cb1.addItem(s1);
					am.aas.cb1.addItem(s1);
					JOptionPane.showMessageDialog(am.aas.b2,"Subject Added");
					
					String q1="create table "+s1+" (sno int(100),question varchar(300),answer varchar(30),o1 varchar(30),o2 varchar(30),o3 varchar(30),o4 varchar(30))";
					
					st3.executeUpdate(q1);
					
					con.close();
					am.aas.tx1.setText("");
			}	
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
			System.out.println("ramji");
		}
		if(e.getSource()==am.aas.b2)
		{
			String s1=am.aas.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				Statement st3=con.createStatement();
				
					String q="select * from sub";
					ResultSet rs=st1.executeQuery(q);
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from sub where subjetc='"+s1+"' ";
							st2.executeUpdate(q1);
							JOptionPane.showMessageDialog(am.aas.b2,"Subject Deleted");
						}
					}
					String q2="drop table "+s1+" ";
					st3.executeUpdate(q2);
					
					am.aaq.cb1.removeItem(s1);
					am.aas.cb1.removeItem(s1);
					// am.aaq.cb1.addItem(s1);
					con.close();
					
					am.aas.tx1.setText("");
			}	
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
			System.out.println("ramji");
		}
		
		if(e.getSource()==am.auq.tx6)
		{
			System.out.println("jai shree ram ji");
			String s1=am.auq.tx6.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				
				String q="select * from "+selectsubject+" ";
				
				ResultSet rs=st1.executeQuery(q);
				
				while(rs.next())
				{
					if(s1.equals(rs.getString(1)))
					{
						am.auq.ta1.setText(rs.getString(2));
						am.auq.tx5.setText(rs.getString(3));
						am.auq.tx1.setText(rs.getString(4));
						am.auq.tx2.setText(rs.getString(5));
						am.auq.tx3.setText(rs.getString(6));
						am.auq.tx4.setText(rs.getString(7));
					}
				}
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.adq.tx6)
		{
			System.out.println("jai shree ram ji");
			String s1=am.adq.tx6.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				
				String q="select * from "+selectsubject+" ";
				
				ResultSet rs=st1.executeQuery(q);
				
				while(rs.next())
				{
					if(s1.equals(rs.getString(1)))
					{
						am.adq.ta1.setText(rs.getString(2));
						am.adq.tx5.setText(rs.getString(3));
						am.adq.tx1.setText(rs.getString(4));
						am.adq.tx2.setText(rs.getString(5));
						am.adq.tx3.setText(rs.getString(6));
						am.adq.tx4.setText(rs.getString(7));
					}
				}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.asp.b1)
		{
			String s1=am.asp.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				
				String q="select * from studentregister";
				
				ResultSet rs=st1.executeQuery(q);
				
				while(rs.next())
				{
					if(s1.equals(rs.getString(10)))
					{
						am.asp.tx2.setText(rs.getString(1));
						am.asp.tx3.setText(rs.getString(2));
						am.asp.tx4.setText(rs.getString(3));
						am.asp.tx5.setText(rs.getString(4));
						am.asp.tx6.setText(rs.getString(6));
						am.asp.tx7.setText(rs.getString(7));
						am.asp.tx8.setText(rs.getString(8));
						am.asp.tx9.setText(rs.getString(9));
						am.asp.tx10.setText(rs.getString(10));
						am.asp.tx11.setText(rs.getString(11));
					}
				}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==rd.b1)
		{
			jp.z=1;jp.h1=1;jp.y=10;jp.x=0;jp.h=0;
			jp.tx2.setText("");
			xx=1;yy=1;
			sa=0;
			javashow=0;
			phpshow=0;
			htmlshow=0;
			jp.bg.clearSelection();
			cr.show(cn,"studentmenu");
						
		}
		if(e.getSource()==rd.b2)
		{
			cr.show(cn,"home");
			String s1=rd.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				
				String q="update studentregister set result='"+s1+"' where roll='"+stu+"' ";
				
				st1.executeUpdate(q);
				System.out.println("result");	
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		if(e.getSource()==hd.b1)
		{
			cr.show(cn,"adminlogin");
		}
		// if(e.getSource()==sm.se.b1)
		// {
			// if(javashow==1)
			// {
				// cr.show(cn,"jpd");
			// }
			// else if(phpshow==1)
			// {
				// cr.show(cn,"pjpd");
			// }
			// else if(htmlshow==1)
			// {
				// cr.show(cn,"hjpd");
			// }
			// ++h;
		// }
		
		if(e.getSource()==am.al.b1)
		{
			
			am.aaq.cb1.removeAllItems();
			cr.show(cn,"home");
			
			am.asp.tx2.setText("");
			am.asp.tx3.setText("");
			am.asp.tx4.setText("");
			am.asp.tx5.setText("");
			am.asp.tx6.setText("");
			am.asp.tx7.setText("");
			am.asp.tx8.setText("");
			am.asp.tx9.setText("");
			am.asp.tx10.setText("");
			am.asp.tx11.setText("");
			am.asp.tx1.setText("");
		}
		
		if(e.getSource()==hd.b3)
		{
			cr.show(cn,"sregister");
		}
		
		if(e.getSource()==hd.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sl.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==sr.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==ald.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==sm.se.b1)
		{
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				String abhi="";
				// if(abhi!=null)
				// {
					abhi="select * from "+selectsubject2+" ";
				// }
				ResultSet rs1=st1.executeQuery(abhi);
				
					while(rs1.next() && onetime==1)
					{
						jp.h=1;
						jp.tx1.setText(rs1.getString(2));
						jp.rb1.setLabel(rs1.getString(4));
						jp.rb2.setLabel(rs1.getString(5));
						jp.rb3.setLabel(rs1.getString(6));
						jp.rb4.setLabel(rs1.getString(7));
						cr.show(cn,"jpd");
						onetime++;
					}
						onetime=1;
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sr.b1)
		{
			String s1=sr.tx1.getText();
			String s2=sr.tx2.getText();
			String s3=sr.tx3.getText();
			String s4=sr.tx4.getText();
			String s5=sr.tx5.getText();
			String s6=sr.tx6.getText();
			String s7=sr.tx7.getText();
			String s8=sr.tx8.getText();
			String s9="";
			String s10="";
			String s11="";
			if(sr.rb1.isSelected())
			{
				s9=sr.rb1.getLabel();
			}
			else if(sr.rb2.isSelected())
			{
				s9=sr.rb2.getLabel();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				ch=101;
				Statement st=con.createStatement();
				Statement st1=con.createStatement();
				{
					String q="select * from studentregister";
					ResultSet rs1=st1.executeQuery(q);
					while(rs1.next())
					{
						++ch;
					}
						s10=""+ch;
				}
				String q="insert into studentregister values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"','"+s8+"','"+s9+"','"+s10+"','"+s11+"')";
				if(s4.equals(s5))
				{
					JOptionPane.showMessageDialog(sr.b1,"Your RollNo="+ch);	
					st.executeUpdate(q);	
				}
				else
				{
					JOptionPane.showMessageDialog(sr.b1,"Confirm Password does not match ");	
				}
				
				sr.tx1.setText("");
				sr.tx1.setText("First Name");
				
				sr.tx2.setText("");
				sr.tx2.setText("Last Name");
				
				sr.tx3.setText("");
				sr.tx3.setText("Email");
				
				sr.tx4.setText("");
				sr.tx4.setText("Password");
				
				sr.tx5.setText("");
				sr.tx5.setText("Confirm Password");
				
				sr.tx6.setText("");
				sr.tx6.setText("DD/MM/YYYY");
				
				sr.tx7.setText("");
				sr.tx7.setText("Mobile Number");
				
				sr.tx8.setText("");
				sr.tx8.setText("City/state");
				
				sr.tx1.setForeground(Color.gray);	
				sr.tx2.setForeground(Color.gray);	
				sr.tx3.setForeground(Color.gray);	
				sr.tx4.setForeground(Color.gray);	
				sr.tx5.setForeground(Color.gray);	
				sr.tx6.setForeground(Color.gray);	
				sr.tx7.setForeground(Color.gray);	
				sr.tx8.setForeground(Color.gray);	
				
				if(sr.rb1.isSelected() || sr.rb2.isSelected())
				{
					sr.bg.clearSelection();
				}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sm.slog.b1)
		{
			cr.show(cn,"home");
			in=0;
			xx=1;
			sm.se.cb1.removeAllItems();
		}
		
		
		if(e.getSource()==sl.b1)
		{
			String s100=sl.tx1.getText();
			String s200=sl.tx2.getText();
			String s300=sl.tx3.getText();
			stu=s300;
			String s400=sl.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				Statement st3=con.createStatement();
				Statement st10=con.createStatement();
				
				String q2="select * from studentregister";
				ResultSet rs2=st1.executeQuery(q2);
				while(rs2.next())
				{
					++in;
				}
				
				{
					String q10="select * from sub";
					ResultSet rs1=st10.executeQuery(q10);
					while(rs1.next())
					{
						String s11=rs1.getString(1);
						sm.se.cb1.addItem(s11);
					}
				}
				
				
				String q="select * from studentregister";
				ResultSet rs=st1.executeQuery(q);
				
				
				
				
				while(rs.next())
				{
					if(s100.equals(rs.getString(1)) && s200.equals(rs.getString(2)) && s300.equals(rs.getString(10)) && s400.equals(rs.getString(4)))
					{
						i=1;
						 // jp.h=1;
						cr.show(cn,"studentmenu");
						System.out.println("Student Login");				
					}
				}
				if(i==0)
				{
					JOptionPane.showMessageDialog(sl.b1,"invalid name and password");
				}

				// String abhi="select * from "+selectsubject2+" ";
				
				// ResultSet rs1=st2.executeQuery(abhi);	
				
				// int x=1;	
					// while(rs1.next() && onetime==1)
					// {
						// jp.tx1.setText(rs1.getString(2));
						// jp.rb1.setLabel(rs1.getString(4));
						// jp.rb2.setLabel(rs1.getString(5));
						// jp.rb3.setLabel(rs1.getString(6));
						// jp.rb4.setLabel(rs1.getString(7));
						
						// onetime++;
					// }
					
						// onetime=1;
				sl.tx1.setText("");
				sl.tx1.setText("First Name");
				
				sl.tx2.setText("");
				sl.tx2.setText("Last Name");
				
				sl.tx3.setText("");
				sl.tx3.setText("RollNo");
				
				sl.tx4.setText("");
				sl.tx4.setText("Password");
				
				sl.tx1.setForeground(Color.gray);	
				sl.tx2.setForeground(Color.gray);	
				sl.tx3.setForeground(Color.gray);	
				sl.tx4.setForeground(Color.gray);	
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		
		if(e.getSource()==am.ard.b1)
		{
			int x=0;
			System.out.println("Palsahab");
			String s1="",s2="",s3="",s4="";
			
			if(e.getSource()==am.ard.b1)
			{
				s1=am.ard.tx1.getText();
				s2=am.ard.tx2.getText();
				s3=am.ard.tx3.getText();
				s4=am.ard.tx4.getText();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into adminregister values('"+s1+"','"+s2+"','"+s3+"','"+s4+"')";
				JOptionPane.showMessageDialog(am.ard.b1,"Admin Register Successful");
							
				st.executeUpdate(q);	
				System.out.println("Admin Registered");				
				
					
				am.ard.tx1.setText("");
				am.ard.tx1.setText("First Name");
				
				am.ard.tx2.setText("");
				am.ard.tx2.setText("Last Name");
				
				am.ard.tx3.setText("");
				am.ard.tx3.setText("Email");
				
				am.ard.tx4.setText("");
				am.ard.tx4.setText("Password");
				
				am.ard.tx1.setForeground(Color.gray);	
				am.ard.tx2.setForeground(Color.gray);	
				am.ard.tx3.setForeground(Color.gray);	
				am.ard.tx4.setForeground(Color.gray);	
				
				con.close();
				
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.aaq.b2)
		{
			int x=0;
			String s1="",s2="",s3="",s4="",s5="",s6="",s7="";
			if(e.getSource()==am.aaq.b2)
			{
				s1=am.aaq.tx6.getText();
				s2=am.aaq.ta1.getText().trim();
				s3=am.aaq.tx5.getText();
				s4=am.aaq.tx1.getText();
				s5=am.aaq.tx2.getText();
				s6=am.aaq.tx3.getText();
				s7=am.aaq.tx4.getText();
				x=1;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
					String q="insert into "+selectsubject+" values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
					JOptionPane.showMessageDialog(am.aaq.b1,"Question Add Successful");
					st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from "+selectsubject+" ";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}	
				am.aaq.tx1.setText("");
				am.aaq.tx2.setText("");
				am.aaq.tx3.setText("");
				am.aaq.tx4.setText("");
				am.aaq.tx5.setText("");
				am.aaq.ta1.setText("");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.auq.b2)
		{
			String s1="",s2="",s3="",s4="",s5="",s6="",s7="";
			int x=0;
			if(e.getSource()==am.auq.b2)
			{
				s1=am.auq.tx6.getText();
				s2=am.auq.ta1.getText().trim();
				s3=am.auq.tx5.getText();
				s4=am.auq.tx1.getText();
				s5=am.auq.tx2.getText();
				s6=am.auq.tx3.getText();
				s7=am.auq.tx4.getText();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
				String q="update "+selectsubject+" SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				JOptionPane.showMessageDialog(am.auq.b1,"Question Update Successful");
		
				}
				System.out.println("data update");
				am.auq.tx1.setText("");
				am.auq.tx2.setText("");
				am.auq.tx3.setText("");
				am.auq.tx4.setText("");
				am.auq.tx5.setText("");
				am.auq.ta1.setText("");
				con.close();
			}		
				
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==ald.b1)
		{
			String s1=ald.tx1.getText();
			String s2=ald.tx2.getText();
			String s3=ald.tx3.getText();
			String s4=ald.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				Statement st10=con.createStatement();
				
				String q="select * from adminregister";				
				
				{
					String q10="select * from sub";
					ResultSet rs=st10.executeQuery(q10);
					while(rs.next())
					{
						String s11=rs.getString(1);
						am.aaq.cb1.addItem(s11);
						am.aas.cb1.addItem(s11);
					}
				}
				
				
				{
					ResultSet rs=st.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)) && s2.equals(rs.getString(2)) && s3.equals(rs.getString(3)) && s4.equals(rs.getString(4)))
						{
							cr.show(cn,"adminmenu");	
							i=1;
							System.out.println("welcome");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"Please use correct id and password");
					}
				}

				{
					String q1="select * from java";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}
				
				ald.tx1.setText("");
				ald.tx1.setText("First Name");
				
				ald.tx2.setText("");
				ald.tx2.setText("Last Name");
				
				ald.tx3.setText("");
				ald.tx3.setText("Email");
				
				ald.tx4.setText("");
				ald.tx4.setText("Password");
				
				ald.tx1.setForeground(Color.gray);	
				ald.tx2.setForeground(Color.gray);	
				ald.tx3.setForeground(Color.gray);	
				ald.tx4.setForeground(Color.gray);	

					
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.adq.b2)
		{
			int x=0;
			String s1="",s2="",s3="";
			if(e.getSource()==am.adq.b2)
			{
				s1=am.adq.tx6.getText();
				x=1;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from "+selectsubject+" ";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from "+selectsubject+" where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
							JOptionPane.showMessageDialog(am.adq.b1,"Delete Question");
							i=1;
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(am.adq.b1,"invalid sno.");
					}
				}	
				String q1="select * from "+selectsubject+" ";				
				
				{
					int o=0;
					ResultSet rs1=st2.executeQuery(q1);	
					while(rs1.next())
					{
						++o;
					}
					am.aaq.tx6.setText(""+ ++o);
				}
				am.adq.tx1.setText("");
				am.adq.tx2.setText("");
				am.adq.tx3.setText("");
				am.adq.tx4.setText("");
				am.adq.tx5.setText("");
				am.adq.tx6.setText("");
				am.adq.ta1.setText("");
			con.close();
		}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==jp.b1 && sa<9)
		{
			// sa=9;
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			else if(jp.rb2.isSelected())
			{
				coll[sa]=jp.rb2.getLabel();
			}
			else if(jp.rb3.isSelected())
			{
				coll[sa]=jp.rb3.getLabel();
			}
			else if(jp.rb4.isSelected())
			{
				coll[sa]=jp.rb4.getLabel();
			}
			if(coll[sa]!=null)
			{
				System.out.println("khali nhi h");
				jp.bg.clearSelection();					
			}
			else
			{
				System.out.println("khali h");
			}
			++sa;
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from "+selectsubject2+" ";
				// if(xx < in){
					xx+=1;
					ResultSet rs=st1.executeQuery(abhi);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							jp.tx1.setText(rs.getString(2));
							jp.rb1.setLabel(rs.getString(4));
							jp.rb2.setLabel(rs.getString(5));
							jp.rb3.setLabel(rs.getString(6));
							jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
						// sa++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("n="+xx);
					
					if(xx==9)
					{
						if(jp.rb1.getLabel().equals(coll[8]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[8]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[8]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[8]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(jp.rb1.getLabel().equals(coll[7]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[7]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[7]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[7]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==7)
					{
						if(jp.rb1.getLabel().equals(coll[6]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[6]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[6]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[6]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(jp.rb1.getLabel().equals(coll[5]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[5]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[5]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[5]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(jp.rb1.getLabel().equals(coll[4]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[4]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[4]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[4]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(jp.rb1.getLabel().equals(coll[3]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[3]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[3]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[3]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(jp.rb1.getLabel().equals(coll[2]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[2]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[2]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[2]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
						if(jp.rb1.getLabel().equals(coll[1]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[1]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[1]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[1]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(jp.rb1.getLabel().equals(coll[0]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[0]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[0]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[0]) )
						{
							jp.rb4.setSelected(true);
						}
					}
				
					
				// }
				System.out.println("sa="+sa);
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		if(e.getSource()==jp.b2)
		{
			sa=9;
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			else if(jp.rb2.isSelected())
			{
				coll[sa]=jp.rb2.getLabel();
			}
			else if(jp.rb3.isSelected())
			{
				coll[sa]=jp.rb3.getLabel();
			}
			else if(jp.rb4.isSelected())
			{
				coll[sa]=jp.rb4.getLabel();
			}
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from "+selectsubject2+" ";
				int x=0,kk=0;
				
				ResultSet rs=st1.executeQuery(abhi);
				while(rs.next())
				{
						if(coll[x].equals(rs.getString(3)))
						{
							rd.tx[x].setText("Right");
							rd.tx[x].setBackground(Color.GREEN);
							rd.tx[x].setForeground(Color.WHITE);
							kk+=10;	
						}
						else
						{
							rd.tx[x].setText("Wrong");	
							rd.tx[x].setBackground(Color.RED);
							rd.tx[x].setForeground(Color.WHITE);							
						}
						if(x<9)
						{
							x++;
						}
						rd.tx1.setText(""+kk+"%");
				}
				cr.show(cn,"result");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);
			}
				
		}
		
		if(e.getSource()==jp.b3 && sa>0)
		{
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from "+selectsubject2+" ";
				
				if(xx>1){
					xx=xx-1;	
					ResultSet rs=st1.executeQuery(abhi);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							jp.tx1.setText(rs.getString(2));
							jp.rb1.setLabel(rs.getString(4));
							jp.rb2.setLabel(rs.getString(5));
							jp.rb3.setLabel(rs.getString(6));
							jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("p="+xx);
				}
					--sa;
				System.out.println("sa="+sa);
					if(xx==9)
					{
						if(jp.rb1.getLabel().equals(coll[8]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[8]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[8]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[8]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(jp.rb1.getLabel().equals(coll[7]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[7]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[7]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[7]) )
						{
							jp.rb4.setSelected(true);
						} 
					}
					
					if(xx==7)
					{
						if(jp.rb1.getLabel().equals(coll[6]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[6]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[6]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[6]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(jp.rb1.getLabel().equals(coll[5]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[5]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[5]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[5]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(jp.rb1.getLabel().equals(coll[4]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[4]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[4]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[4]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(jp.rb1.getLabel().equals(coll[3]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[3]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[3]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[3]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(jp.rb1.getLabel().equals(coll[2]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[2]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[2]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[2]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
			
			if(jp.rb1.getLabel().equals(coll[1]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[1]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[1]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[1]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(jp.rb1.getLabel().equals(coll[0]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[0]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[0]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[0]) )
						{
							jp.rb4.setSelected(true);
						}
					}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==am.aaq.cb1)
		{
			selectsubject=(String)am.aaq.cb1.getSelectedItem();
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
					String q1="select * from "+selectsubject+" "; 
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println("aaa");	
			}	
		}
		if(e.getSource()==sm.se.cb1)
		{
			System.out.println("palsahab");
			selectsubject2=(String)sm.se.cb1.getSelectedItem();
		}
		
	}
}
class ResultDemo extends JPanel
{
	JTextField tx[]=new JTextField[10];
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8,tx9,tx10,tx11;
	Font f=new Font("",Font.BOLD,25);
	int x=120,y=150,w=100,h=50;
	JButton b1,b2;
	
	ResultDemo(FDemo f1)
	{
		setLayout(null);
		
		
		l11=new JLabel("Percentage %");
		l11.setBounds(550,120,250,52);
		l11.setFont(f);
		add(l11);	
		
		tx1=new JTextField("");
		tx1.setBounds(550,170,200,50);
		tx1.setFont(f);
		add(tx1);
		
		for(int i=0;i<=9;i++)
		{
			tx[i]=new JTextField();
			tx[i].setBounds(x,y,w,h);
			tx[i].setForeground(Color.BLACK);
			tx[i].setFont(f);
			add(tx[i]);
			y+=50;
		}
		
		l1=new JLabel("Q.1");
		l1.setBounds(50,150,100,52);
		l1.setFont(f);
		add(l1);	
		
		l2=new JLabel("Q.2");
		l2.setBounds(50,200,100,52);
		l2.setFont(f);
		add(l2);
		
		l3=new JLabel("Q.3");
		l3.setBounds(50,250,100,52);
		l3.setFont(f);
		add(l3);
		
		l4=new JLabel("Q.4");
		l4.setBounds(50,300,100,52);
		l4.setFont(f);
		add(l4);
		
		l5=new JLabel("Q.5");
		l5.setBounds(50,350,100,52);
		l5.setFont(f);
		add(l5);
		
		l6=new JLabel("Q.6");
		l6.setBounds(50,400,100,52);
		l6.setFont(f);
		add(l6);
		
		l7=new JLabel("Q.7");
		l7.setBounds(50,450,100,52);
		l7.setFont(f);
		add(l7);	
		
		l8=new JLabel("Q.8");
		l8.setBounds(50,500,100,52);
		l8.setFont(f);
		add(l8);
		
		l9=new JLabel("Q.9");
		l9.setBounds(50,550,100,52);
		l9.setFont(f);
		add(l9);	
		
		l10=new JLabel("Q.10");
		l10.setBounds(50,600,100,52);
		l10.setFont(f);
		add(l10);	
		
		// l12=new JLabel("If you want to give exam again then press below button");
		// l12.setBounds(400,300,700,52);
		// l12.setFont(f);
		// add(l12);	
		
		
		// b1=new JButton("Press");
		// b1.setBounds(550,400,200,52);
		// b1.setFont(f);
		// add(b1);
		
		b2=new JButton("Go To Home");
		b2.setBounds(550,600,200,52);
		b2.setFont(f);
		add(b2);
		// b1.addActionListener(f1);
		b2.addActionListener(f1);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(10,100,250,600,50,50);
		g.fillRoundRect(500,100,300,150,50,50);
		// g.fillRoundRect(500,350,300,150,50,50);
		g.fillRoundRect(500,550,300,150,50,50);
	}
}
class online
{
	public static void main(String... ar)
	{
		FDemo f=new FDemo();
		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		f.setUndecorated(true);
		// f.setAlwaysOnTop(true);
		// f.setLocationByPlatform(true);
		f.setVisible(true);
		f.setSize(screensize.width,screensize.height);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	}
}