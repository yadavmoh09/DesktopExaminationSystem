import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
class FDemo extends JFrame implements ActionListener
{
	JPDemo jp;
	StartDemo str;
	LoginDemo ld;
	HomeDemo hd;
	AdminLoginDemo ald;
	AdminMenu am;
	AdminAddQuestion aaq;
	AdminUpdateQuestion auq;
	AdminDeleteQuestion adq;
	AdminStudentProfile asp;
	AdminLogout al;
	StudentRegister sr;
	StudentLogin sl;
	StudentMenu sm;
	StudentLogout slog;
	
	int set=0;
	static int count=1;
	 int g=0;
	int y=1,result=0,n=1,ll=1,ex=0,v=0;
	Container cn=getContentPane();
	String a1,a2,a3,a4,a5;
	String s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,
		   s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25;
	CardLayout cr;
	ResultDemo rd;
	JButton b1;
	int i=0;
	FDemo()
	{
		cr=new CardLayout();
		setLayout(cr);
		
			hd=new HomeDemo(this);
			cn.add("home",hd);

			ald=new AdminLoginDemo(this);
			cn.add("adminlogin",ald);
		
			am=new AdminMenu(this);
			cn.add("adminmenu",am);
			
			sr=new StudentRegister(this);
			cn.add("sregister",sr);
			
			sl=new StudentLogin(this);
			cn.add("sLogin",sl);
			
			sm=new StudentMenu(this);
			cn.add("studentmenu",sm);	
			
			rd=new ResultDemo();
			cn.add("result",rd);
	}
	public void actionPerformed(ActionEvent e)
	{
		
		// if(sm.jp.rb1.isSelected() || sm.jp.rb2.isSelected() || sm.jp.rb3.isSelected() || sm.jp.rb4.isSelected())
			// {
				// if(count==1 && sm.jp.rb3.isSelected())
				// {
					// rd.tx2.setText(" Right");
					// count++;
				// }
				// else if(count==1)
				// {
					// rd.tx2.setText(" Wrong");
					// count++;
				// }
				// else if(count==2 && sm.jp.rb2.isSelected())
				// {
					// rd.tx3.setText(" Right");
					// count++;
				// }
				// else if(count==2)
				// {
					// rd.tx3.setText(" Wrong");
					// count++;
				// }
				// else if(count==3 && sm.jp.rb4.isSelected())
				// {
					// rd.tx4.setText(" Right");
					// count++;
				// }
				// else if(count==3)
				// {
					// rd.tx4.setText(" Wrong");
					// count++;
				// }
				// else if(count==4 && sm.jp.rb1.isSelected())
				// {
					// rd.tx5.setText(" Right");
					// count++;
				// }
				// else if(count==4)
				// {
					// rd.tx5.setText(" Wrong");
					// count++;
				// }
				// else if(count==5 && sm.jp.rb4.isSelected())
				// {
					// rd.tx6.setText(" Right");
					// count++;
				// }
				// else if(count==5)
				// {
					// rd.tx6.setText(" Wrong");
					// count++;
				// }
			// }
			
		if(e.getSource()==hd.b1)
		{
			cr.show(cn,"adminlogin");
		}
		
		if(e.getSource()==am.al.b1)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==hd.b3)
		{
			cr.show(cn,"sregister");
		}
		
		if(e.getSource()==hd.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sl.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==sr.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sr.b3)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==ald.b2)
		{
			cr.show(cn,"home");
		}

		if(e.getSource()==sm..b1)
		{
			String s1=sr.tx1.getText();
			String s2=sr.tx2.getText();
			String s3=sr.tx3.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into studentregister values('"+s1+"','"+s2+"','"+s3+"')";
				
				st.executeUpdate(q);	
				
				System.out.println("Student Registered");				
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		
		
		if(e.getSource()==sr.b1)
		{
			String s1=sr.tx1.getText();
			String s2=sr.tx2.getText();
			String s3=sr.tx3.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into studentregister values('"+s1+"','"+s2+"','"+s3+"')";
				
				st.executeUpdate(q);	
				
				System.out.println("Student Registered");				
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sm.slog.b1)
		{
			cr.show(cn,"home");
		}
		if(e.getSource()==sl.b1)
		{
			String s100=sl.tx1.getText();
			String s200=sl.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from studentregister";
				ResultSet rs=st1.executeQuery(q);
				while(rs.next())
				{
					if(s100.equals(rs.getString(1)) && s200.equals(rs.getString(3)) )
					{
						i=1;
						 sm.jp.h=1;
						cr.show(cn,"studentmenu");
						System.out.println("Student Login");				
					}
				}
				if(i==0)
				{
					JOptionPane.showMessageDialog(sl.b1,"invalid name and password");
				}
				//_________________________________

				String q1="select * from questiontable";
				
				ResultSet rs1=st2.executeQuery(q1);	
				
				int x=1;	
					while(rs1.next())
					{
						if(x==1)
						{
							s1=rs1.getString(2);
							s2=rs1.getString(4);
							s3=rs1.getString(5);
							s4=rs1.getString(6);
							s5=rs1.getString(7);
							a1=rs1.getString(3);
						}
						if(x==2)
						{
							s6=rs1.getString(2);
							s7=rs1.getString(4);
							s8=rs1.getString(5);
							s9=rs1.getString(6);
							s10=rs1.getString(7);
							a2=rs1.getString(3);
						}
						if(x==3)
						{
							s11=rs1.getString(2);
							s12=rs1.getString(4);
							s13=rs1.getString(5);
							s14=rs1.getString(6);
							s15=rs1.getString(7);
							a3=rs1.getString(3);
						}
						if(x==4)
						{
							s16=rs1.getString(2);
							s17=rs1.getString(4);
							s18=rs1.getString(5);
							s19=rs1.getString(6);
							s20=rs1.getString(7);
							a4=rs1.getString(3);
						}
						if(x==5)
						{
							s21=rs1.getString(2);
							s22=rs1.getString(4);
							s23=rs1.getString(5);
							s24=rs1.getString(6);
							s25=rs1.getString(7);
							a5=rs1.getString(3);
						}
						x++;
						sm.jp.tx1.setText(s1);
						sm.jp.rb1.setLabel(s2);
						sm.jp.rb2.setLabel(s3);
						sm.jp.rb3.setLabel(s4);
						sm.jp.rb4.setLabel(s5);
					}
					
				//_________________________________
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		
		if(e.getSource()==am.ard.b1)
		{
			String s1=am.ard.tx1.getText();
			String s2=am.ard.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into adminregister values('"+s1+"','"+s2+"')";
				
				st.executeUpdate(q);	
				System.out.println("Admin Registered");				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.aaq.b2)
		{
			String s1=am.aaq.tx6.getText();
			String s2=am.aaq.ta1.getText().trim();
			String s3=am.aaq.tx5.getText();
			String s4=am.aaq.tx1.getText();
			String s5=am.aaq.tx2.getText();
			String s6=am.aaq.tx3.getText();
			String s7=am.aaq.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
				String q="insert into questiontable values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
				
				st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}	
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.auq.b2)
		{
			String s1=am.auq.tx6.getText();
			String s2=am.auq.ta1.getText().trim();
			String s3=am.auq.tx5.getText();
			String s4=am.auq.tx1.getText();
			String s5=am.auq.tx2.getText();
			String s6=am.auq.tx3.getText();
			String s7=am.auq.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
				String q="update questiontable SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				}
				

				System.out.println("data update");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==ald.b1)
		{
			String s1=ald.tx1.getText();
			String s2=ald.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="select * from adminregister";				
				
				{
					ResultSet rs=st.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)) && s2.equals(rs.getString(2)))
						{
							cr.show(cn,"adminmenu");	
							i=1;
							System.out.println("welcome");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"Please use correct id and password");
					}
				}

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}
					
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println("aaa");	
			}
		}
		
		if(e.getSource()==am.adq.b1)
		{
			String s1=am.adq.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from questiontable";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from questiontable where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
				}

				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==sm.jp.b1)
		{
			if(y==1)
			{
				g++;
				sm.jp.tx1.setText(s6);
				sm.jp.rb1.setLabel(s7);
				sm.jp.rb2.setLabel(s8);
				sm.jp.rb3.setLabel(s9);
				sm.jp.rb4.setLabel(s10);
				if(sm.jp.rb3.isSelected())
				{
					result++;
					System.out.println(result);
				}	
			}
			else if(y==2)
			{
				g++;
				sm.jp.tx1.setText(s11);
				sm.jp.rb1.setLabel(s12);
				sm.jp.rb2.setLabel(s13);
				sm.jp.rb3.setLabel(s14);
				sm.jp.rb4.setLabel(s15);
				if(sm.jp.rb2.isSelected())
				{
					result++;
					System.out.println(result);
				}				
			}
			else if(y==3)
			{
				g++;
				sm.jp.tx1.setText(s16);
				sm.jp.rb1.setLabel(s17);
				sm.jp.rb2.setLabel(s18);
				sm.jp.rb3.setLabel(s19);
				sm.jp.rb4.setLabel(s20);
				if(sm.jp.rb4.isSelected())
				{
					result++;
					System.out.println(result);
				}			
			}
			else if(y==4)
			{
				g++;
				sm.jp.tx1.setText(s21);
				sm.jp.rb1.setLabel(s22);
				sm.jp.rb2.setLabel(s23);
				sm.jp.rb3.setLabel(s24);
				sm.jp.rb4.setLabel(s25);
				if(sm.jp.rb1.isSelected())
				{
					result++;
					System.out.println(result);
				}			
			}
			if(y<=4)
			{
				y++;
				System.out.println("ny="+y);
			}
			if(sm.jp.rb1.isSelected()==false && sm.jp.rb2.isSelected()==false && sm.jp.rb3.isSelected()==false && sm.jp.rb4.isSelected()==false && count<=4)
			{
				System.out.println("jai shree radhe");
				count++;
				System.out.println("n="+count);
			}
	}
			
		if(e.getSource()==sm.jp.b2 && y==5)
		{
			if(sm.jp.rb4.isSelected())
			{
				v=1;
				result++;
			}
			rd.tx1.setText(""+result);
			System.out.println(result);
			cr.show(cn,"result");
			if(rd.tx2.getText().equals(""))
			{
				rd.tx2.setText(" Skip");
			}
			if(rd.tx3.getText().equals(""))
			{
				rd.tx3.setText(" Skip");
			}
			if(rd.tx4.getText().equals(""))
			{
				rd.tx4.setText(" Skip");
			}
			if(rd.tx5.getText().equals(""))
			{
				rd.tx5.setText(" Skip");
			}
			if(rd.tx6.getText().equals(""))
			{
				rd.tx6.setText(" Skip");
			}
		}
		if(e.getSource()==sm.jp.b3)
		{
			if(g==1)
			{
				sm.jp.tx1.setText(s1);
				sm.jp.rb1.setLabel(s2);
				sm.jp.rb2.setLabel(s3);
				sm.jp.rb3.setLabel(s4);
				sm.jp.rb4.setLabel(s5);
				g--;
			}
			if(g==2)
			{
				sm.jp.tx1.setText(s6);
				sm.jp.rb1.setLabel(s7);
				sm.jp.rb2.setLabel(s8);
				sm.jp.rb3.setLabel(s9);
				sm.jp.rb4.setLabel(s10);
				g--;
			}
			if(g==3)
			{
				sm.jp.tx1.setText(s11);
				sm.jp.rb1.setLabel(s12);
				sm.jp.rb2.setLabel(s13);
				sm.jp.rb3.setLabel(s14);
				sm.jp.rb4.setLabel(s15);
				g--;
			}
			if(g==4)
			{
				sm.jp.tx1.setText(s16);
				sm.jp.rb1.setLabel(s17);
				sm.jp.rb2.setLabel(s18);
				sm.jp.rb3.setLabel(s19);
				sm.jp.rb4.setLabel(s20);
				g--;
			}
			if(y>=2)
			{
				y--;
				System.out.println("yp="+y);
			}
		
			if(sm.jp.rb1.isSelected()==false && sm.jp.rb2.isSelected()==false && sm.jp.rb3.isSelected()==false && sm.jp.rb4.isSelected()==false && count>=2)
			{
				System.out.println("jai shree Krinshna");
				--count;
				System.out.println("p1="+count);
			}
		
		}
	}
}
class JPDemo extends JPanel implements ActionListener
{
	int x=60,y=4;
	JTextArea tx1,tx2;
	ButtonGroup bg;
	int h=0;
	JRadioButton rb1,rb2,rb3,rb4;
	JButton b1,b2,b3;
	JLabel l1,l2,l3;
	int z=1,h1=1;
	Timer t;
	Font f=new Font("",Font.BOLD,25);
	ImageIcon ii;
	String s1;
	Image i;
	JPDemo(FDemo f1)
	{
		setLayout(null);
		
		bg=new ButtonGroup();
		
		tx1=new JTextArea();
		tx1.setFont(f);
		tx1.setBounds(150,200,760,30);
		add(tx1);
		
		tx2=new JTextArea();
		tx2.setFont(f);
		tx2.setBounds(20,150,70,30);
		add(tx2);
		
		l2=new JLabel("Time");
		l2.setFont(f);
		l2.setBounds(20,120,200,20);
		add(l2);
		
		rb1=new JRadioButton("option1");
		bg.add(rb1);
		rb1.setFont(f);
		rb1.setBounds(150,300,200,50);
		add(rb1);
		
		rb2=new JRadioButton("option2");
		rb2.setFont(f);
		bg.add(rb2);
		rb2.setBounds(150,350,200,50);
		add(rb2);
		
		rb3=new JRadioButton("option3");
		rb3.setFont(f);
		bg.add(rb3);
		rb3.setBounds(150,400,200,50);
		add(rb3);
		
		rb4=new JRadioButton("option4");
		rb4.setBounds(150,450,200,50);
		rb4.setFont(f);
		bg.add(rb4);
		add(rb4);
		
		b1=new JButton("Next");
		b1.setFont(f);
		b1.setBounds(600,500,150,30);
		add(b1);
		
		b3=new JButton("Privious");
		b3.setFont(f);
		b3.setBounds(450,500,150,30);
		add(b3);
		
		b2=new JButton("Submit");
		b2.setFont(f);
		b2.setBounds(750,500,150,30);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		b3.addActionListener(f1);
		
		t=new Timer(1000,this);
		t.start();
	}
	public void actionPerformed(ActionEvent e)
	{
		if(h==1)
		{
			if(z==1)
			{
				if(x>0)
				{
					tx2.setText(""+y+":"+x);
				}
				else
				{
					x=60;y--;
				}
				--x;
			}
			if(y==-1)
			{
				z=0;
				tx2.setText(""+"0:0");
				y=-2;
			}
		}
	}
}
class ResultDemo extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6;
	Font f=new Font("",Font.BOLD,25);
	ImageIcon ii;
	Image i;
	ResultDemo()
	{
		setLayout(null);
		
		l1=new JLabel("Result");
		l1.setBounds(420,200,200,50);
		l1.setFont(f);
		add(l1);
		
		l2=new JLabel("Q.1");
		l2.setBounds(50,300,50,50);
		l2.setFont(f);
		add(l2);
		
		tx2=new JTextField();
		tx2.setBounds(100,300,100,52);
		tx2.setFont(f);
		add(tx2);
		
		l3=new JLabel("Q.2");
		l3.setBounds(50,350,50,50);
		l3.setFont(f);
		add(l3);
		
		tx3=new JTextField();
		tx3.setBounds(100,350,100,52);
		tx3.setFont(f);
		add(tx3);
		
		
		l4=new JLabel("Q.3");
		l4.setBounds(50,400,50,50);
		l4.setFont(f);
		add(l4);
		
		tx4=new JTextField();
		tx4.setBounds(100,400,100,52);
		tx4.setFont(f);
		add(tx4);
		
		
		l5=new JLabel("Q.4");
		l5.setBounds(50,450,50,50);
		l5.setFont(f);
		add(l5);
		
		tx5=new JTextField();
		tx5.setBounds(100,450,100,52);
		tx5.setFont(f);
		add(tx5);
		
		
		l6=new JLabel("Q.5");
		l6.setBounds(50,500,50,50);
		l6.setFont(f);
		add(l6);
		
		tx6=new JTextField();
		tx6.setBounds(100,500,100,52);
		tx6.setFont(f);
		add(tx6);
		
		tx1=new JTextField();
		tx1.setForeground(Color.white);
		tx1.setBackground(Color.black);
		tx1.setFont(f);
		add(tx1);
	}
}
class online
{
	public static void main(String... ar)
	{
		FDemo f =new FDemo();
		f.setVisible(true);
		f.setBounds(0,0,1300,900);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	}
}