import javax.swing.*;
import java.awt.*;
class LoginDemo extends JPanel
{
	JLabel l1,l2,l3;
	JTextField tx1,tx2,tx3;
	JButton b1;
	Font f=new Font("",Font.BOLD,20);
	ImageIcon ii;
	Image i;
	LoginDemo(FDemo f1)
	{
		setLayout(null);
		l1=new JLabel("Enter Name");
		l1.setBounds(580,350,200,30);
		l1.setForeground(Color.white);
		l1.setFont(f);
		add(l1);
		
		tx1=new JTextField();
		tx1.setBounds(840,350,250,30);
		tx1.setFont(f);
		add(tx1);
		
		l2=new JLabel("Enter RollNo.");
		l2.setBounds(580,450,200,30);
		l2.setForeground(Color.white);
		l2.setFont(f);
		add(l2);
		
		
		tx2=new JTextField();
		tx2.setBounds(840,450,250,30);
		tx2.setFont(f);
		add(tx2);
		
		l3=new JLabel("Enter Password");
		l3.setBounds(580,550,250,30);
		l3.setForeground(Color.white);
		l3.setFont(f);
		add(l3);
		
		
		tx3=new JTextField();
		tx3.setBounds(840,550,250,30);
		tx3.setFont(f);
		add(tx3);
		
		b1=new JButton("Login");
		b1.setBounds(840,650,150,30);
		b1.setFont(f);
		add(b1);
		
		b1.addActionListener(f1);
		ii=new ImageIcon("co.jpg");
		i=ii.getImage();
	}
}