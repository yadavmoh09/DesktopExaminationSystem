import javax.swing.*;
import java.awt.*;
class AdminStudentProfile extends JPanel
{
	JTextArea ta1;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8,tx9,tx10,tx11,tx12;
	JButton b1;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	Font f=new Font("",Font.BOLD,25);
	AdminStudentProfile(FDemo f1)
	{
		setLayout(null);
		
		l1=new JLabel("Enter RollNo.");
		l1.setBounds(10,100,200,50);
		add(l1);
		
		tx1=new JTextField();
		tx1.setBounds(210,100,50,30);
		add(tx1);
			
		b1=new JButton("Enter");
		b1.setBounds(200,200,100,50);
		add(b1);
		
		b1.addActionListener(f1);
			
		l1.setFont(f);		
		tx1.setFont(f);		
		b1.setFont(f);		
		
		l2=new JLabel("First Name");
		l2.setFont(f);
		l2.setBounds(500,50,200,30);
		add(l2);
		
		l3=new JLabel("Last Name");
		l3.setFont(f);
		l3.setBounds(500,120,200,30);
		add(l3);
		
		l4=new JLabel("Email");
		l4.setFont(f);
		l4.setBounds(500,190,200,30);
		add(l4);
		
		l5=new JLabel("Password");
		l5.setFont(f);
		l5.setBounds(500,260,200,30);
		add(l5);
		
		l6=new JLabel("DOB");
		l6.setFont(f);
		l6.setBounds(500,330,200,30);
		add(l6);
		
		l7=new JLabel("Mobile");
		l7.setFont(f);
		l7.setBounds(500,400,200,30);
		add(l7);
		
		l8=new JLabel("City/State");
		l8.setFont(f);
		l8.setBounds(500,470,200,30);
		add(l8);
		
		l9=new JLabel("Gender");
		l9.setFont(f);
		l9.setBounds(500,540,200,30);
		add(l9);
		
		l10=new JLabel("RollNo.");
		l10.setFont(f);
		l10.setBounds(500,610,200,30);
		add(l10);
		
		l11=new JLabel("Result");
		l11.setFont(f);
		l11.setBounds(500,680,200,30);
		add(l11);
		
		tx2=new JTextField();
		tx2.setFont(f);
		tx2.setBounds(800,50,300,30);
		add(tx2);
		
		tx3=new JTextField();
		tx3.setFont(f);
		tx3.setBounds(800,120,300,30);
		add(tx3);
		
		
		tx4=new JTextField();
		tx4.setFont(f);
		tx4.setBounds(800,190,300,30);
		add(tx4);
		
		tx5=new JTextField();
		tx5.setFont(f);
		tx5.setBounds(800,260,300,30);
		add(tx5);
		
		tx6=new JTextField();
		tx6.setFont(f);
		tx6.setBounds(800,330,300,30);
		add(tx6);
		
		tx7=new JTextField();
		tx7.setFont(f);
		tx7.setBounds(800,400,300,30);
		add(tx7);
		
		tx8=new JTextField();
		tx8.setFont(f);
		tx8.setBounds(800,470,300,30);
		add(tx8);
		
		tx9=new JTextField();
		tx9.setFont(f);
		tx9.setBounds(800,540,300,30);
		add(tx9);
		
		tx10=new JTextField();
		tx10.setFont(f);
		tx10.setBounds(800,610,300,30);
		add(tx10);
		
		tx11=new JTextField();
		tx11.setFont(f);
		tx11.setBounds(800,680,300,30);
		add(tx11);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));	
		g.fillRoundRect(5,50,350,250,50,50);
		g.fillRoundRect(450,20,750,750,50,50);
	}
}