-- MySQL dump 10.13  Distrib 5.7.23, for Win32 (AMD64)
--
-- Host: localhost    Database: online
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminlogin`
--

DROP TABLE IF EXISTS `adminlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminlogin` (
  `name` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminlogin`
--

LOCK TABLES `adminlogin` WRITE;
/*!40000 ALTER TABLE `adminlogin` DISABLE KEYS */;
/*!40000 ALTER TABLE `adminlogin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminregister`
--

DROP TABLE IF EXISTS `adminregister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminregister` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminregister`
--

LOCK TABLES `adminregister` WRITE;
/*!40000 ALTER TABLE `adminregister` DISABLE KEYS */;
INSERT INTO `adminregister` VALUES ('abhi','pal','abhi@gmail.com','111'),('golu','pal','golu@gmail.com','222'),('pawan','ser','pppp','333'),('1','1','1','1'),('h','h','h','h'),('2','2','2','2');
/*!40000 ALTER TABLE `adminregister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aj`
--

DROP TABLE IF EXISTS `aj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aj` (
  `sno` int(100) DEFAULT NULL,
  `question` varchar(300) DEFAULT NULL,
  `answer` varchar(30) DEFAULT NULL,
  `o1` varchar(30) DEFAULT NULL,
  `o2` varchar(30) DEFAULT NULL,
  `o3` varchar(30) DEFAULT NULL,
  `o4` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aj`
--

LOCK TABLES `aj` WRITE;
/*!40000 ALTER TABLE `aj` DISABLE KEYS */;
/*!40000 ALTER TABLE `aj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `android`
--

DROP TABLE IF EXISTS `android`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `android` (
  `sno` int(100) DEFAULT NULL,
  `question` varchar(300) DEFAULT NULL,
  `answer` varchar(30) DEFAULT NULL,
  `o1` varchar(30) DEFAULT NULL,
  `o2` varchar(30) DEFAULT NULL,
  `o3` varchar(30) DEFAULT NULL,
  `o4` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `android`
--

LOCK TABLES `android` WRITE;
/*!40000 ALTER TABLE `android` DISABLE KEYS */;
/*!40000 ALTER TABLE `android` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `html`
--

DROP TABLE IF EXISTS `html`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `html` (
  `sno` int(11) DEFAULT NULL,
  `question` varchar(200) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `o1` varchar(20) DEFAULT NULL,
  `o2` varchar(20) DEFAULT NULL,
  `o3` varchar(20) DEFAULT NULL,
  `o4` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `html`
--

LOCK TABLES `html` WRITE;
/*!40000 ALTER TABLE `html` DISABLE KEYS */;
INSERT INTO `html` VALUES (1,'Which Tag is use to create Pearagraph ?','<p>','<phh>','<pr>','<p>','<prg>'),(2,'Which tag is use to break line ?','<br>','<break>','<b>','<br>','<brk>'),(3,'............ is Known as father of html ?','TimBerners','TimBerners','Patrick','James','Mike'),(4,'Which tag is used for put scrolling text in a web page ?','<marquee>','<con>','<marquee>','<run>','<mar>'),(5,'Which Syntex is true for comment in html ?','<!-- -->','<!--  -->','   //','<%-- %>','<!% -->'),(6,'Which tag is use for make Horizontal line ?','<hr>','<h>','<hl>','<hr>','<hrl>'),(7,'Which language is use for create a attractive web page ?','css','js','css','jquery','php'),(8,'Which tag is use for define JavaScript function ?','<script>','<link>','<add>','<kapil>','<script>'),(9,'Which tag is use to get information from use ?','<form>','<table>','<get>','<form>','<hvr>'),(10,'hariom ?','pp','jj','pp','ll','gg');
/*!40000 ALTER TABLE `html` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `java`
--

DROP TABLE IF EXISTS `java`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `java` (
  `sno` int(11) DEFAULT NULL,
  `question` varchar(200) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `o1` varchar(20) DEFAULT NULL,
  `o2` varchar(20) DEFAULT NULL,
  `o3` varchar(20) DEFAULT NULL,
  `o4` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `java`
--

LOCK TABLES `java` WRITE;
/*!40000 ALTER TABLE `java` DISABLE KEYS */;
INSERT INTO `java` VALUES (1,'Can we write try block without catch block?','Yes','Yes','Sometime','No','N.O.T'),(2,'How many methods are there in Object class ?','12','10','12','11','13'),(3,'How many method are private in object class ?','1','2','3','1','0'),(4,'How many methods are Final in object Class ?','6','8','3','7','6'),(5,'How many methods are protected in object class ?','2','1','3','2','4'),(6,'What is name of super class of all Exception ?','Exception','Throwable','Runtime','object','Exception'),(7,'Java was developed By.....?','james','Patricks','james','mike','dannies'),(8,'What is the purpose of Finalize() method ?','Closing','Opening','Stop','Closing','NOT'),(9,'Can Unreferenced object be referenced again ?','Never','Yes','Never','sometime','NOT'),(10,'Deamon Thread is the best example of.....?','GC','Overloading','Inheritance','Overriding','GC');
/*!40000 ALTER TABLE `java` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `UNAME` varchar(30) DEFAULT NULL,
  `UROLLNO` varchar(30) DEFAULT NULL,
  `UPASS` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('abhishek','101','111111'),('pawan','102','222222'),('sacchidanand','103','333333'),('mohit','104','444444'),('rohit','105','555555'),('ramraj','106','666666'),('sunil','107','777777'),('rohan','108','888888'),('rahul','109','999999');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online`
--

DROP TABLE IF EXISTS `online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online` (
  `question` varchar(50) DEFAULT NULL,
  `answer` varchar(30) DEFAULT NULL,
  `option1` varchar(30) DEFAULT NULL,
  `option2` varchar(30) DEFAULT NULL,
  `option3` varchar(30) DEFAULT NULL,
  `option4` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online`
--

LOCK TABLES `online` WRITE;
/*!40000 ALTER TABLE `online` DISABLE KEYS */;
INSERT INTO `online` VALUES ('Q.1 what is first name of java ?','oak','rock','brock','oak','cock'),('Q.2 java was discoverd in ?','1996','1999','1996','1991','1995'),('Q.3 whose discoverd java ?','jamesgosling','patricks','mike','wilson','jamesgosling'),('Q.4 java not support _______ inheritance ?','multiple','multiple','multilevel','double','single'),('Q.5 java language syntax similer like ?','c++','php','html','python','c++');
/*!40000 ALTER TABLE `online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oo`
--

DROP TABLE IF EXISTS `oo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oo`
--

LOCK TABLES `oo` WRITE;
/*!40000 ALTER TABLE `oo` DISABLE KEYS */;
/*!40000 ALTER TABLE `oo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questiontable`
--

DROP TABLE IF EXISTS `questiontable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questiontable` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) DEFAULT NULL,
  `answer` varchar(30) DEFAULT NULL,
  `o1` varchar(25) DEFAULT NULL,
  `o2` varchar(25) DEFAULT NULL,
  `o3` varchar(25) DEFAULT NULL,
  `o4` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questiontable`
--

LOCK TABLES `questiontable` WRITE;
/*!40000 ALTER TABLE `questiontable` DISABLE KEYS */;
INSERT INTO `questiontable` VALUES (1,'when exception is generated ?','runtime','compiletime','both','runtime','all'),(2,'How many methods are there in object class ?','12','13','11','12','10'),(3,'Can an unreferenced object be referenced again ?','never','never','sometime','yes','all'),(4,'What is the example of Daemon Thread ?','G.C','G.C','K.C','C.C','A.C'),(5,'How many methos are final in object class ?','6','5','6','4','7'),(6,'How many methods are private in object class ?','1','2','4','3','1'),(7,'Which class Example of Singletone class ?','Runtime','Integer','Runtime','String','Boolean'),(8,'What is return type of factory method ?','Object','Object','float','int','class'),(9,'Can we create a method inside the method ?','no','yes','both','no','nothing'),(10,'By default which type of cloning support java ?','shallow','shallow','oen','deep','close'),(11,'qqqq','q','q','q','q','q'),(12,'qqqqq','q','qq','q','q','q');
/*!40000 ALTER TABLE `questiontable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studentregister`
--

DROP TABLE IF EXISTS `studentregister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `studentregister` (
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `cpassword` varchar(30) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `city_state` varchar(40) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `roll` int(200) DEFAULT NULL,
  `result` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studentregister`
--

LOCK TABLES `studentregister` WRITE;
/*!40000 ALTER TABLE `studentregister` DISABLE KEYS */;
INSERT INTO `studentregister` VALUES ('abhi','pal','abhi@gmail.com','11','11','11/11/2019','9191919191','mp/indore','Male',101,'90%'),('golu','pal','golu@gmail.com','22','22','8/11/2019','8181818181','M.P/indore','Male',102,NULL),('pawan','seroniya','pawan@gmail.com','pawan','pawan','15/02/1998','9926530108','Indore/m.p','Male',103,'50%'),('1','1','1','1','1','1','1','1','Male',104,'20%'),('mohit','yadav','mohit@gmail.com','11','11','11/11/1999','9191919191','Indore/m.p','Male',105,'40%'),('chetan','gayke','chetangayke06@gmail.com','ram','ram','06/10/1998','9893143256','indore','Male',106,'60%'),('abhi','pal','abhi@gmail.com','111','111','8/12/1998','9191919191','indore/m.p','Male',107,'10%'),('1','1','1','1','1','1','1','1','Male',108,''),('kapil','mangulle','kapil@gmail.com','111','111','8/1/1999','9191919191','in/mp','Male',109,''),('ajay','raput','kj','o','o','o','o','o','Male',110,''),('i','i','i','i','i','i','i','i','Male',111,''),('aman','singh','aman@gmail.com','321','321','11/11/2019','91919191919','indore/m.p','Male',112,'90%'),('ram','ram','ram@gmail.com','0987','0987','8/12/2001','9191911919','indore/m.p','Male',113,'30%'),('1','1','1','1','1','1','1','1','Male',114,'');
/*!40000 ALTER TABLE `studentregister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub`
--

DROP TABLE IF EXISTS `sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub` (
  `subjetc` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub`
--

LOCK TABLES `sub` WRITE;
/*!40000 ALTER TABLE `sub` DISABLE KEYS */;
INSERT INTO `sub` VALUES ('java'),('html'),('Android'),('AJ'),('sirji'),('pal');
/*!40000 ALTER TABLE `sub` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-14 21:02:01
