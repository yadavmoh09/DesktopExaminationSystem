import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class StudentLogin extends JPanel implements KeyListener
{
	JLabel l1;
	JTextField tx1,tx2,tx3,tx4;
	JButton b1,b2;
	Font f=new Font("",Font.BOLD,50);
	StudentLogin(FDemo f1)
	{
		setLayout(null);

		l1=new JLabel("Student Login");
		l1.setBounds(420,220,450,60);
		l1.setFont(f);
		l1.setForeground(Color.WHITE);
		add(l1);
		
		Font f=new Font("",Font.BOLD,25);
		tx1=new JTextField("First Name");
		tx1.setBounds(420,300,350,40);
		tx1.setForeground(Color.gray);
		tx1.setFont(f);
		add(tx1);
		
		tx2=new JTextField("Last Name");
		tx2.setBounds(420,370,350,40);
		tx2.setForeground(Color.gray);
		tx2.setFont(f);
		add(tx2);
		
		tx3=new JTextField("RollNo");
		tx3.setBounds(420,440,350,40);
		tx3.setForeground(Color.gray);
		tx3.setFont(f);
		add(tx3);
		
		tx4=new JTextField("Password");
		tx4.setForeground(Color.gray);
		tx4.setBounds(420,510,350,40);
		tx4.setFont(f);
		add(tx4);
		
		
		b1=new JButton("Login");
		b1.setBounds(420,580,150,40);
		b1.setFont(f);
		b1.setBackground(Color.GRAY);
		b1.setForeground(Color.WHITE);
		add(b1);
		
		b2=new JButton("Back");
		b2.setBounds(620,580,150,40);
		b2.setFont(f);
		b2.setBackground(Color.GRAY);
		b2.setForeground(Color.WHITE);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		
		tx1.addKeyListener(this);
		tx2.addKeyListener(this);
		tx3.addKeyListener(this);
		tx4.addKeyListener(this);
		
		// tx1.setBackground(Color.BLACK);
		// tx1.setForeground(Color.white);
	}
	public void keyPressed(KeyEvent e)
	{
		if(e.getSource()==tx1)
		{
			String s1=tx1.getText();
			if(s1.equals("First Name"))
			{
				tx1.setText("");
				tx1.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx2)
		{
			String s1=tx2.getText();
			if(s1.equals("Last Name"))
			{
				tx2.setText("");
				tx2.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx3)
		{
			String s1=tx3.getText();
			if(s1.equals("RollNo"))
			{
				tx3.setText("");
				tx3.setForeground(Color.BLACK);
			}
		}
		if(e.getSource()==tx4)
		{
			String s1=tx4.getText();
			if(s1.equals("Password"))
			{
				tx4.setText("");
				tx4.setForeground(Color.BLACK);
			}
		}
	}
	
	public void keyReleased(KeyEvent e)
	{
		if(e.getSource()==tx1)
		{
			String s1=tx1.getText().trim();
			if(s1.equals(""))
			{
				tx1.setText("First Name");
				tx1.setForeground(Color.gray);
			}
		}
		
		if(e.getSource()==tx2)
		{
			String s1=tx2.getText().trim();
			if(s1.equals(""))
			{
				tx2.setText("Last Name");
				tx2.setForeground(Color.gray);
			}
		}
		if(e.getSource()==tx3)
		{
			String s1=tx3.getText().trim();
			if(s1.equals(""))
			{
				tx3.setText("RollNo");
				tx3.setForeground(Color.gray);
			}
		}
		if(e.getSource()==tx4)
		{
			String s1=tx4.getText().trim();
			if(s1.equals(""))
			{
				tx4.setText("Password");
				tx4.setForeground(Color.gray);
			}
		}
	}
	public void keyTyped(KeyEvent e){}	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		// setBackground(new Color(174,190,232));
		setBackground(new Color(207,207,207));
		setBackground(Color.WHITE);
		setForeground(Color.gray);
		// setForeground(new Color(134,181,223));
		g.fillRoundRect(300,200,600,500,50,50);
			
	}
}