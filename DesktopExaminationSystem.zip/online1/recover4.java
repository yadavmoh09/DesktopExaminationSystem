import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
class FDemo extends JFrame implements ActionListener
{
	JPDemo jp;
	StartDemo str;
	LoginDemo ld;
	HomeDemo hd;
	AdminLoginDemo ald;
	AdminMenu am;
	AdminAddQuestion aaq;
	AdminUpdateQuestion auq;
	AdminDeleteQuestion adq;
	AdminStudentProfile asp;
	AdminLogout al;
	StudentRegister sr;
	StudentLogin sl;
	StudentMenu sm;
	StudentLogout slog;
	
	int xx=1,yy=1,in=0,sa=0;
	String coll[]=new String[10];
	int set=0,onetime=1;
	static int count=1;
	int y=1,result=0,n=1,ll=1,v=0;

	Container cn=getContentPane();
	CardLayout cr;
	ResultDemo rd;
	JButton b1;
	int i=0;
	FDemo()
	{
		cr=new CardLayout();
		setLayout(cr);
		
			hd=new HomeDemo(this);
			cn.add("home",hd);

			ald=new AdminLoginDemo(this);
			cn.add("adminlogin",ald);
		
			am=new AdminMenu(this);
			cn.add("adminmenu",am);
			
			sr=new StudentRegister(this);
			cn.add("sregister",sr);
			
			sl=new StudentLogin(this);
			cn.add("sLogin",sl);
			
			sm=new StudentMenu(this);
			cn.add("studentmenu",sm);	
			
			rd=new ResultDemo();
			cn.add("result",rd);
	}
	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getSource()==hd.b1)
		{
			cr.show(cn,"adminlogin");
		}
		
		if(e.getSource()==am.al.b1)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==hd.b3)
		{
			cr.show(cn,"sregister");
		}
		
		if(e.getSource()==hd.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sl.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==sr.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sr.b3)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==ald.b2)
		{
			cr.show(cn,"home");
		}

		if(e.getSource()==sr.b1)
		{
			String s1=sr.tx1.getText();
			String s2=sr.tx2.getText();
			String s3=sr.tx3.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into studentregister values('"+s1+"','"+s2+"','"+s3+"')";
				
				st.executeUpdate(q);	
				
				System.out.println("Student Registered");				
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sm.slog.b1)
		{
			cr.show(cn,"home");
			in=0;
			xx=1;
		}
		
		
		if(e.getSource()==sl.b1)
		{
			String s100=sl.tx1.getText();
			String s200=sl.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				Statement st3=con.createStatement();
				
				String q2="select * from questiontable";
				ResultSet rs2=st1.executeQuery(q2);

				while(rs2.next())
				{
					++in;
				}
				
				String q="select * from studentregister";
				ResultSet rs=st1.executeQuery(q);
				while(rs.next())
				{
					if(s100.equals(rs.getString(1)) && s200.equals(rs.getString(3)) )
					{
						i=1;
						 sm.jp.h=1;
						cr.show(cn,"studentmenu");
						System.out.println("Student Login");				
					}
				}
				if(i==0)
				{
					JOptionPane.showMessageDialog(sl.b1,"invalid name and password");
				}

				String q1="select * from questiontable";
				
				ResultSet rs1=st2.executeQuery(q1);	
				
				int x=1;	
					while(rs1.next() && onetime==1)
					{
						sm.jp.tx1.setText(rs1.getString(2));
						sm.jp.rb1.setLabel(rs1.getString(4));
						sm.jp.rb2.setLabel(rs1.getString(5));
						sm.jp.rb3.setLabel(rs1.getString(6));
						sm.jp.rb4.setLabel(rs1.getString(7));
						
						onetime++;
					}
					
						onetime=1;
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		
		if(e.getSource()==am.ard.b1)
		{
			String s1=am.ard.tx1.getText();
			String s2=am.ard.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into adminregister values('"+s1+"','"+s2+"')";
				
				st.executeUpdate(q);	
				System.out.println("Admin Registered");				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.aaq.b2)
		{
			String s1=am.aaq.tx6.getText();
			String s2=am.aaq.ta1.getText().trim();
			String s3=am.aaq.tx5.getText();
			String s4=am.aaq.tx1.getText();
			String s5=am.aaq.tx2.getText();
			String s6=am.aaq.tx3.getText();
			String s7=am.aaq.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
				String q="insert into questiontable values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
				
				st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}	
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.auq.b2)
		{
			String s1=am.auq.tx6.getText();
			String s2=am.auq.ta1.getText().trim();
			String s3=am.auq.tx5.getText();
			String s4=am.auq.tx1.getText();
			String s5=am.auq.tx2.getText();
			String s6=am.auq.tx3.getText();
			String s7=am.auq.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				{
				String q="update questiontable SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				}
				

				System.out.println("data update");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==ald.b1)
		{
			String s1=ald.tx1.getText();
			String s2=ald.tx2.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="select * from adminregister";				
				
				{
					ResultSet rs=st.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)) && s2.equals(rs.getString(2)))
						{
							cr.show(cn,"adminmenu");	
							i=1;
							System.out.println("welcome");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"Please use correct id and password");
					}
				}

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}
					
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println("aaa");	
			}
		}
		
		if(e.getSource()==am.adq.b1)
		{
			String s1=am.adq.tx1.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from questiontable";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from questiontable where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
				}	
				String q1="select * from questiontable";				
				
				{
					int o=0;
					ResultSet rs1=st2.executeQuery(q1);	
					while(rs1.next())
					{
						++o;
					}
					am.aaq.tx6.setText(""+ ++o);
				}

				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sm.jp.b1 && sa<9)
		{
			
			if(sm.jp.rb1.isSelected())
			{
				coll[sa]=sm.jp.rb1.getLabel();
			}
			else if(sm.jp.rb2.isSelected())
			{
				coll[sa]=sm.jp.rb2.getLabel();
			}
			else if(sm.jp.rb3.isSelected())
			{
				coll[sa]=sm.jp.rb3.getLabel();
				
			}
			else if(sm.jp.rb4.isSelected())
			{
				coll[sa]=sm.jp.rb4.getLabel();
			}
			// else if(sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false)
			// {
			// }
			// if(coll[sa]==null)
			// {
				// sm.jp.bg.clearSelection();
			// }
			System.out.println("sa="+sa);
			if(coll[sa]!=null)
			{
				System.out.println("khali nhi h");
				sm.jp.bg.clearSelection();					
			}
			else
			{
				System.out.println("khali h");
			}
			++sa;
			
			//________________________				
			//________________________				
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from questiontable";				
				if(xx < in){
					xx+=1;
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							sm.jp.tx1.setText(rs.getString(2));
							sm.jp.rb1.setLabel(rs.getString(4));
							sm.jp.rb2.setLabel(rs.getString(5));
							sm.jp.rb3.setLabel(rs.getString(6));
							sm.jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("n="+xx);
					
					if(xx==9)
					{
						if(sm.jp.rb1.getLabel().equals(coll[8]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[8]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[8]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[8]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(sm.jp.rb1.getLabel().equals(coll[7]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[7]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[7]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[7]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==7)
					{
						if(sm.jp.rb1.getLabel().equals(coll[6]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[6]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[6]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[6]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(sm.jp.rb1.getLabel().equals(coll[5]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[5]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[5]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[5]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(sm.jp.rb1.getLabel().equals(coll[4]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[4]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[4]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[4]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(sm.jp.rb1.getLabel().equals(coll[3]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[3]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[3]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[3]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(sm.jp.rb1.getLabel().equals(coll[2]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[2]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[2]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[2]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
						if(sm.jp.rb1.getLabel().equals(coll[1]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[1]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[1]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[1]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(sm.jp.rb1.getLabel().equals(coll[0]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[0]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[0]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[0]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
				
					
				}
				// sm.jp.bg.clearSelection();	
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
	}
			
		if(e.getSource()==sm.jp.b2)
		{
			for(int i=0;i<=9;i++)
			{
				System.out.println(coll[i]);	
			}
		}
		if(e.getSource()==sm.jp.b3 && sa>0)
		{
			if(sa==10)
			{
				sa=9;
			}
			
			if(sm.jp.rb1.isSelected())
			{
				coll[sa]=sm.jp.rb1.getLabel();
			}
			
			else if(sm.jp.rb1.isSelected())
			{
				coll[sa]=sm.jp.rb1.getLabel();
			}
			
			else if(sm.jp.rb1.isSelected())
			{
				coll[sa]=sm.jp.rb1.getLabel();
			}
			
			else if(sm.jp.rb1.isSelected())
			{
				coll[sa]=sm.jp.rb1.getLabel();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from questiontable";				
				
				if(xx>1){
					xx=xx-1;	
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							sm.jp.tx1.setText(rs.getString(2));
							sm.jp.rb1.setLabel(rs.getString(4));
							sm.jp.rb2.setLabel(rs.getString(5));
							sm.jp.rb3.setLabel(rs.getString(6));
							sm.jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("p="+xx);
				}
				if(sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false && sm.jp.rb1.isSelected()==false)
				{
					--sa;
				}
				System.out.println("sa="+sa);
					if(xx==9)
					{
						if(sm.jp.rb1.getLabel().equals(coll[8]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[8]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[8]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[8]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(sm.jp.rb1.getLabel().equals(coll[7]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[7]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[7]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[7]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==7)
					{
						if(sm.jp.rb1.getLabel().equals(coll[6]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[6]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[6]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[6]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(sm.jp.rb1.getLabel().equals(coll[5]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[5]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[5]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[5]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(sm.jp.rb1.getLabel().equals(coll[4]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[4]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[4]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[4]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(sm.jp.rb1.getLabel().equals(coll[3]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[3]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[3]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[3]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(sm.jp.rb1.getLabel().equals(coll[2]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[2]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[2]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[2]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
						if(sm.jp.rb1.getLabel().equals(coll[1]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[1]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[1]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[1]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(sm.jp.rb1.getLabel().equals(coll[0]) )
						{
							sm.jp.rb1.setSelected(true);
						}
						else if(sm.jp.rb2.getLabel().equals(coll[0]) )
						{
							sm.jp.rb2.setSelected(true);
						}
						else if(sm.jp.rb3.getLabel().equals(coll[0]) )
						{
							sm.jp.rb3.setSelected(true);
						}
						else if(sm.jp.rb4.getLabel().equals(coll[0]) )
						{
							sm.jp.rb4.setSelected(true);
						}
					}
				
				
					
					
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		// if(e.getSource()==sm.jp.b1)
		// {
			// sm.jp.bg.clearSelection();	
		// }
	}
}
class JPDemo extends JPanel implements ActionListener
{
	int x=60,y=4;
	JTextArea tx1,tx2;
	ButtonGroup bg;
	int h=0;
	JRadioButton rb1,rb2,rb3,rb4;
	JButton b1,b2,b3;
	JLabel l1,l2,l3;
	int z=1,h1=1;
	Timer t;
	Font f=new Font("",Font.BOLD,25);
	ImageIcon ii;
	String s1;
	Image i;
	JPDemo(FDemo f1)
	{
		setLayout(null);
		
		bg=new ButtonGroup();
		
		tx1=new JTextArea();
		tx1.setFont(f);
		tx1.setBounds(150,200,760,30);
		add(tx1);
		
		tx2=new JTextArea();
		tx2.setFont(f);
		tx2.setBounds(20,150,70,30);
		add(tx2);
		
		l2=new JLabel("Time");
		l2.setFont(f);
		l2.setBounds(20,120,200,20);
		add(l2);
		
		rb1=new JRadioButton("option1");
		bg.add(rb1);
		rb1.setFont(f);
		rb1.setBounds(150,300,200,50);
		add(rb1);
		
		rb2=new JRadioButton("option2");
		rb2.setFont(f);
		bg.add(rb2);
		rb2.setBounds(150,350,200,50);
		add(rb2);
		
		rb3=new JRadioButton("option3");
		rb3.setFont(f);
		bg.add(rb3);
		rb3.setBounds(150,400,200,50);
		add(rb3);
		
		rb4=new JRadioButton("option4");
		rb4.setBounds(150,450,200,50);
		rb4.setFont(f);
		bg.add(rb4);
		add(rb4);
		
		b1=new JButton("Next");
		b1.setFont(f);
		b1.setBounds(600,500,150,30);
		add(b1);
		
		b3=new JButton("Privious");
		b3.setFont(f);
		b3.setBounds(450,500,150,30);
		add(b3);
		
		b2=new JButton("Submit");
		b2.setFont(f);
		b2.setBounds(750,500,150,30);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		b3.addActionListener(f1);
		
		t=new Timer(1000,this);
		t.start();
	}
	public void actionPerformed(ActionEvent e)
	{
		if(h==1)
		{
			if(z==1)
			{
				if(x>0)
				{
					tx2.setText(""+y+":"+x);
				}
				else
				{
					x=60;y--;
				}
				--x;
			}
			if(y==-1)
			{
				z=0;
				tx2.setText(""+"0:0");
				y=-2;
			}
		}
	}
}
class ResultDemo extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8,tx9,tx10,tx11;
	Font f=new Font("",Font.BOLD,25);
	ResultDemo()
	{
		setLayout(null);
		tx1=new JTextField();
		tx1.setBounds(420,100,200,50);
		tx1.setFont(f);
		add(tx1);
		
		tx2=new JTextField();
		tx2.setBounds(100,150,100,52);
		tx2.setFont(f);
		add(tx2);
		
		tx3=new JTextField();
		tx3.setBounds(100,200,100,52);
		tx3.setFont(f);
		add(tx3);
		
		tx4=new JTextField();
		tx4.setBounds(100,250,100,52);
		tx4.setFont(f);
		add(tx4);
		
		tx5=new JTextField();
		tx5.setBounds(100,300,100,52);
		tx5.setFont(f);
		add(tx5);
		
		tx6=new JTextField();
		tx6.setBounds(100,350,100,52);
		tx6.setFont(f);
		add(tx6);
		
		tx7=new JTextField();
		tx7.setBounds(100,400,100,52);
		tx7.setFont(f);
		add(tx7);
		
		tx8=new JTextField();
		tx8.setBounds(100,450,100,52);
		tx8.setFont(f);
		add(tx8);
		
		tx9=new JTextField();
		tx9.setBounds(100,500,100,52);
		tx9.setFont(f);
		add(tx9);
		
		tx10=new JTextField();
		tx10.setBounds(100,550,100,52);
		tx10.setFont(f);
		add(tx10);
		
	}
}
class recover
{
	public static void main(String... ar)
	{
		FDemo f =new FDemo();
		f.setVisible(true);
		f.setBounds(0,0,1300,900);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	}
}