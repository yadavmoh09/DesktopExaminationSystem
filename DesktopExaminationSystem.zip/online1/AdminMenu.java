import javax.swing.*;
import java.awt.*;
class AdminMenu extends JPanel
{
	AdminAddQuestion aaq;
	AdminUpdateQuestion auq;
	AdminDeleteQuestion adq;
	AdminAddSubject aas;
	AdminLogout al;
	AdminStudentProfile asp;
	AdminRegisterDemo ard;
	JTabbedPane tb;
	AdminMenu(FDemo f1)
	{
		setLayout(new BorderLayout());
		tb=new JTabbedPane();

			aaq=new AdminAddQuestion(f1);
			tb.addTab("Add Question",aaq);	
		
			auq=new AdminUpdateQuestion(f1);
			tb.addTab("Update Question",auq);
			
			adq=new AdminDeleteQuestion(f1);
			tb.addTab("Delete Question",adq);	
			
			aas=new AdminAddSubject(f1);
			tb.addTab("Add/Delete Subject",aas);
			
			asp=new AdminStudentProfile(f1);
			tb.addTab("Student Profile",asp);
			
			ard=new AdminRegisterDemo(f1);
			tb.addTab("Admin Register",ard);
			
			al=new AdminLogout(f1);
			tb.addTab("Logout",al);	

		add(tb);
	}
}