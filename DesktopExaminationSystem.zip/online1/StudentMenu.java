import javax.swing.*;
import java.awt.*;
class StudentMenu extends JPanel
{
	JTabbedPane tb;
	StudentLogout slog;
	StartExam se;
	// ResultDemo rd;
	JPDemo jp;
	StudentMenu(FDemo f)
	{
		setLayout(new BorderLayout());
		tb=new JTabbedPane();
			
			se=new StartExam(f);
			tb.addTab("Examination",se);
			
			slog=new StudentLogout(f);
			tb.addTab("logout",slog);
			
		add(tb);
	}
}
class StudentLogout extends JPanel
{
	JButton b1;
	Font f11=new Font("",Font.BOLD,25);
	StudentLogout(FDemo f)
	{
		setLayout(null);
		
		b1=new JButton("Logout");
		b1.setBounds(500,300,150,40);
		b1.setFont(f11);
		add(b1);
		
		b1.addActionListener(f);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(450,250,250,150,50,50);
	}
}
class StartExam extends JPanel
{
	JButton b1;
	JLabel l1;
	Font f1=new Font("",Font.BOLD,20);
	Font f11=new Font("",Font.BOLD,40);
	JComboBox cb1;
	StartExam(FDemo f)
	{
		setLayout(null);
		
		l1=new JLabel("Select Subject");
		l1.setFont(f11);
		l1.setBounds(500,250,400,50);
		add(l1);
		
		cb1=new JComboBox();
		cb1.setBounds(500,350,100,30);
		cb1.setFont(f1);
		add(cb1);
			
		b1=new JButton("Start");
		b1.setBounds(700,350,100,30);
		b1.setFont(f1);
		add(b1);
		
		b1.addActionListener(f);
		cb1.addItemListener(f);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(450,200,400,300,50,50);
	}
}