import javax.swing.*;
import java.awt.*;
class AdminAddQuestion extends JPanel
{
	FDemo f2=new FDemo(10);
	static int i=2;
	JComboBox cb1;
	JTextArea ta1;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6;
	JButton b1,b2,b3;
	JLabel l1,l2,l3,l4,l5,l6,l7;
	String aq[]=new String[4];
	// String aq[]={"java","php","html","","",""};
	Font f=new Font("",Font.BOLD,20);
	AdminAddQuestion(FDemo f1)
	{
		setLayout(null);

		cb1=new JComboBox();
		cb1.setBounds(500,100,100,50);
		cb1.setFont(f);
		add(cb1);
		
		cb1.addItemListener(f1);
		
		l7=new JLabel("S.No.");
		l7.setBounds(200,100,150,50);
		add(l7);
		
		tx6=new JTextField();
		tx6.setBounds(350,100,50,50);
		add(tx6);
		
		l1=new JLabel("Enter Question");
		l1.setBounds(200,160,200,50);
		add(l1);
		
		ta1=new JTextArea();
		ta1.setBounds(200,200,700,100);
		add(ta1);
		
		l2=new JLabel("1.");
		l2.setBounds(200,340,70,100);
		add(l2);
		
		tx1=new JTextField();
		tx1.setBounds(200,400,100,50);
		add(tx1);

		
		l3=new JLabel("2.");
		l3.setBounds(200,440,70,100);
		add(l3);
		
		tx2=new JTextField();
		tx2.setBounds(200,500,100,50);
		add(tx2);
		
		
		l4=new JLabel("3.");
		l4.setBounds(400,340,70,100);
		add(l4);
		
		tx3=new JTextField();
		tx3.setBounds(400,400,100,50);
		add(tx3);
		
		
		l5=new JLabel("4.");
		l5.setBounds(400,440,70,100);
		add(l5);
		
		tx4=new JTextField();
		tx4.setBounds(400,500,100,50);
		add(tx4);
		
		l6=new JLabel("Answer");
		l6.setBounds(600,390,150,100);
		add(l6);
		
		tx5=new JTextField();
		tx5.setBounds(600,450,100,50);
		add(tx5);
		
		b1=new JButton("Home");
		b1.setBounds(300,600,100,50);
		add(b1);
		
		b2=new JButton("Submit");
		b2.setBounds(500,600,100,50);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
			
		l1.setFont(f);
		l2.setFont(f);
		l3.setFont(f);
		l4.setFont(f);
		l5.setFont(f);
		l6.setFont(f);
		l7.setFont(f);
		ta1.setFont(f);
		tx1.setFont(f);
		tx2.setFont(f);
		tx3.setFont(f);
		tx4.setFont(f);
		tx5.setFont(f);
		tx6.setFont(f);
		b1.setFont(f);
		b2.setFont(f);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(100,50,900,700,50,50);
	}
}