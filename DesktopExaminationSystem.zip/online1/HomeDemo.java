import javax.swing.*;
import java.awt.*;
class HomeDemo extends JPanel
{
	JButton b1,b2,b3;
	Font f=new Font("",Font.BOLD,20);
	ImageIcon ii;
	Image i;
	HomeDemo(FDemo f1)
	{
		setLayout(null);
		
		b1=new JButton("Admin");
		b1.setBounds(500,200,200,50);
		b1.setFont(f);
		b1.setForeground(Color.WHITE);
		b1.setBorder(null);
		b1.setBackground(Color.GRAY);
		add(b1);
		
		b2=new JButton("Sudent Login");
		b2.setBounds(500,400,200,50);
		b2.setFont(f);
		b2.setForeground(Color.WHITE);
		b2.setBorder(null);
		b2.setBackground(Color.GRAY);
		add(b2);
		
		b3=new JButton("Student Register");
		b3.setBounds(500,600,200,50);
		b3.setFont(f);
		b3.setBorder(null);
		b3.setForeground(Color.WHITE);
		b3.setBackground(Color.GRAY);
		add(b3);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		b3.addActionListener(f1);
		
		b1.setFont(f);
		b2.setFont(f);
		b3.setFont(f);
		
		ii=new ImageIcon("go.jpeg");
		i=ii.getImage();
	}
	Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g)	;
		g.drawImage(i,0,0,screensize.width,screensize.height,this);
	}
}