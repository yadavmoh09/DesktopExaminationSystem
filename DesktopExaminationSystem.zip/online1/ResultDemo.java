class ResultDemo extends JPanel
{
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8,tx9,tx10;
	ResultDemo(FDemo f)
	{
		setLayout(null);
		
		l1=new JLabel("Q.1");
		setBound(100,100,50,50);
		add(l1);
	}
}