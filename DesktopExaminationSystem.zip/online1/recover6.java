import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
class FDemo extends JFrame implements ActionListener,ItemListener
{
	Timer t;


	pAdminMenu pam;
	pAdminAddQuestion paaq;
	pAdminUpdateQuestion pauq;
	pAdminDeleteQuestion padq;


	hAdminMenu ham;
	hAdminAddQuestion haaq;
	hAdminUpdateQuestion hauq;
	hAdminDeleteQuestion hadq;



	JPDemo jp;
	StartDemo str;
	AdminAddSubject aas;
	LoginDemo ld;
	HomeDemo hd;
	AdminLoginDemo ald;
	AdminMenu am;
	AdminAddQuestion aaq;
	AdminUpdateQuestion auq;
	AdminDeleteQuestion adq;
	AdminStudentProfile asp;
	AdminLogout al;
	StudentRegister sr;
	StudentLogin sl;
	StudentMenu sm;
	StudentLogout slog;
	
	int xx=1,yy=1,in=0,sa=0;
	String coll[]=new String[10];
	int set=0,pset=0,hset=0,onetime=1;
	static int count=1;
	int y=1,result=0,n=1,ll=1,v=0;
	int x=3,y1=1,z=1;
	static int h=0;

	Container cn=getContentPane();
	CardLayout cr;
	ResultDemo rd;
	JButton b1;
	int i=0;
	static int xxx=0;
	FDemo()
	{
		cr=new CardLayout();
		setLayout(cr);
		
		
			hd=new HomeDemo(this);
			cn.add("home",hd);

			ald=new AdminLoginDemo(this);
			cn.add("adminlogin",ald);
		
			am=new AdminMenu(this);
			cn.add("adminmenu",am);
			
			sr=new StudentRegister(this);
			cn.add("sregister",sr);
			
			sl=new StudentLogin(this);
			cn.add("sLogin",sl);
			
			sm=new StudentMenu(this);
			cn.add("studentmenu",sm);	
			
			jp=new JPDemo(this);
			cn.add("jpd",jp);
			
			rd=new ResultDemo(this);
			cn.add("result",rd);
			
			aas=new AdminAddSubject();
			cn.add("addsubject",aas);
			
			pam=new pAdminMenu(this);
			cn.add("padmin",pam);
			
			ham=new hAdminMenu(this);
			cn.add("hadmin",ham);
			
			t=new Timer(1000,this);
			t.start();
	}
	
	public void itemStateChanged(ItemEvent e)
	{
	
		if(e.getSource()==am.aaq.cb1)
		{
			String s1=(String)am.aaq.cb1.getSelectedItem();
			if(s1.equals("php"))
			{
				cr.show(cn,"padmin");
			}
			else if(s1.equals("html"))
			{
				cr.show(cn,"hadmin");
			}
			System.out.println("jairamji");
		}
		if(e.getSource()==pam.aaq.cb1)
		{
			String s2=(String)pam.aaq.cb1.getSelectedItem();
			if(s2.equals("java"))
			{
				cr.show(cn,"adminmenu");
			}
			else if(s2.equals("html"))
			{
				cr.show(cn,"hadmin");
			}
		}
		if(e.getSource()==ham.aaq.cb1)
		{
		String s3=(String)ham.aaq.cb1.getSelectedItem();
			if(s3.equals("java"))
			{
				cr.show(cn,"adminmenu");
			}
			else if(s3.equals("php"))
			{
				cr.show(cn,"padmin");
			}
		}
		System.out.println("Ramji");
	}
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("SitaRamji");
		// jp.tx2.setText("Ramji");
		if(h==1)
		{
			if(z==1)
			{
				if(x>0)
				{
					jp.tx2.setText(""+y1+":"+x);
				}
				else
				{
					x=60;y1--;
				}
				--x;
			}
			if(y1==-1)
			{
				z=0;
				jp.tx2.setText(""+"0:0");
				y1=-2;
				xxx=1;
			}
		}
		if(xxx==1)
		{
			System.out.println("kkkkkkkkkkkkkkk");
			sa=9;
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			else if(jp.rb2.isSelected())
			{
				coll[sa]=jp.rb2.getLabel();
			}
			else if(jp.rb3.isSelected())
			{
				coll[sa]=jp.rb3.getLabel();
			}
			else if(jp.rb4.isSelected())
			{
				coll[sa]=jp.rb4.getLabel();
			}
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from questiontable";
				int x=0,kk=0;
				
				ResultSet rs=st1.executeQuery(abhi);
				while(rs.next())
				{
						if(coll[x].equals(rs.getString(3)))
						{
							rd.tx[x].setText("Right");
							rd.tx[x].setBackground(Color.GREEN);
							rd.tx[x].setForeground(Color.WHITE);
							kk+=10;	
						}
						else
						{
							rd.tx[x].setText("Wrong");	
							rd.tx[x].setBackground(Color.RED);
							rd.tx[x].setForeground(Color.WHITE);							
						}
						if(x<9)
						{
							x++;
						}
						rd.tx1.setText(""+kk+"%");
				}
				cr.show(cn,"result");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);
			}
		}
			
			
			
			
			
			
			
			// int jj=0;
			// while(jj<10)
			// {
				// if(coll[jj].equals(rs.getString(3)))
						// {
							// rd.tx[x].setText("Right");
							// rd.tx[x].setBackground(Color.GREEN);
							// rd.tx[x].setForeground(Color.WHITE);
							// kk+=10;	
						// }
						// else
						// {
							// rd.tx[x].setText("Wrong");	
							// rd.tx[x].setBackground(Color.RED);
							// rd.tx[x].setForeground(Color.WHITE);							
						// }
			// }
		
		
		
		if(e.getSource()==hd.b1)
		{
			cr.show(cn,"adminlogin");
		}
		if(e.getSource()==sm.se.b1)
		{
			cr.show(cn,"jpd");
			++h;
		}
		
		if(e.getSource()==am.al.b1)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==pam.al.b1)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==hd.b3)
		{
			cr.show(cn,"sregister");
		}
		
		if(e.getSource()==hd.b2)
		{
			cr.show(cn,"sLogin");
		}
		
		if(e.getSource()==sl.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==sr.b2)
		{
			cr.show(cn,"home");
		}
		
		if(e.getSource()==ald.b2)
		{
			cr.show(cn,"home");
		}

		if(e.getSource()==sr.b1)
		{
			String s1=sr.tx1.getText();
			String s2=sr.tx2.getText();
			String s3=sr.tx3.getText();
			String s4=sr.tx4.getText();
			String s5=sr.tx5.getText();
			String s6=sr.tx6.getText();
			String s7=sr.tx7.getText();
			String s8=sr.tx8.getText();
			String s9="";
			if(sr.rb1.isSelected())
			{
				s9=sr.rb1.getLabel();
			}
			else if(sr.rb2.isSelected())
			{
				s9=sr.rb2.getLabel();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into studentregister values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"','"+s8+"','"+s9+"')";
				if(s4.equals(s5))
				{
					JOptionPane.showMessageDialog(sr.b1,"Student Registered");	
					st.executeUpdate(q);	
				}
				else
				{
					JOptionPane.showMessageDialog(sr.b1,"Confirm Password does not match ");	
				}
				
				sr.tx1.setText("");
				sr.tx1.setText("First Name");
				
				sr.tx2.setText("");
				sr.tx2.setText("Last Name");
				
				sr.tx3.setText("");
				sr.tx3.setText("Email");
				
				sr.tx4.setText("");
				sr.tx4.setText("Password");
				
				sr.tx5.setText("");
				sr.tx5.setText("Confirm Password");
				
				sr.tx6.setText("");
				sr.tx6.setText("DD/MM/YYYY");
				
				sr.tx7.setText("");
				sr.tx7.setText("Mobile Number");
				
				sr.tx8.setText("");
				sr.tx8.setText("City/state");
				
				sr.tx1.setForeground(Color.gray);	
				sr.tx2.setForeground(Color.gray);	
				sr.tx3.setForeground(Color.gray);	
				sr.tx4.setForeground(Color.gray);	
				sr.tx5.setForeground(Color.gray);	
				sr.tx6.setForeground(Color.gray);	
				sr.tx7.setForeground(Color.gray);	
				sr.tx8.setForeground(Color.gray);	
				
				if(sr.rb1.isSelected() || sr.rb2.isSelected())
				{
					sr.bg.clearSelection();
				}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==sm.slog.b1)
		{
			cr.show(cn,"home");
			in=0;
			xx=1;
		}
		
		
		if(e.getSource()==sl.b1)
		{
			String s100=sl.tx1.getText();
			String s200=sl.tx2.getText();
			String s300=sl.tx3.getText();
			String s400=sl.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				Statement st3=con.createStatement();
				
				String q2="select * from questiontable";
				ResultSet rs2=st1.executeQuery(q2);

				while(rs2.next())
				{
					++in;
				}
				
				String q="select * from studentregister";
				ResultSet rs=st1.executeQuery(q);
				while(rs.next())
				{
					if(s100.equals(rs.getString(1)) && s200.equals(rs.getString(2)) && s300.equals(rs.getString(3)) && s400.equals(rs.getString(4)))
					{
						i=1;
						 // jp.h=1;
						cr.show(cn,"studentmenu");
						System.out.println("Student Login");				
					}
				}
				if(i==0)
				{
					JOptionPane.showMessageDialog(sl.b1,"invalid name and password");
				}

				String abhi="select * from questiontable";
				
				ResultSet rs1=st2.executeQuery(abhi);	
				
				int x=1;	
					while(rs1.next() && onetime==1)
					{
						jp.tx1.setText(rs1.getString(2));
						jp.rb1.setLabel(rs1.getString(4));
						jp.rb2.setLabel(rs1.getString(5));
						jp.rb3.setLabel(rs1.getString(6));
						jp.rb4.setLabel(rs1.getString(7));
						
						onetime++;
					}
					
						onetime=1;
						
						
							
				sl.tx1.setText("");
				sl.tx1.setText("First Name");
				
				sl.tx2.setText("");
				sl.tx2.setText("Last Name");
				
				sl.tx3.setText("");
				sl.tx3.setText("Email");
				
				sl.tx4.setText("");
				sl.tx4.setText("Password");
				
				sl.tx1.setForeground(Color.gray);	
				sl.tx2.setForeground(Color.gray);	
				sl.tx3.setForeground(Color.gray);	
				sl.tx4.setForeground(Color.gray);	
				
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		
		if(e.getSource()==am.ard.b1 || e.getSource()==pam.ard.b1 || e.getSource()==ham.ard.b1)
		{
			int x=0;
			System.out.println("Palsahab");
			String s1="",s2="",s3="",s4="";
			if(e.getSource()==am.ard.b1)
			{
				s1=am.ard.tx1.getText();
				s2=am.ard.tx2.getText();
				s3=am.ard.tx3.getText();
				s4=am.ard.tx4.getText();
				x=1;
			}
			else if(e.getSource()==pam.ard.b1)
			{
				s1=pam.ard.tx1.getText();
				s2=pam.ard.tx2.getText();
				s3=pam.ard.tx3.getText();
				s4=pam.ard.tx4.getText();
				x=2;
			}
			else if(e.getSource()==ham.ard.b1)
			{
				s1=ham.ard.tx1.getText();
				s2=ham.ard.tx2.getText();
				s3=ham.ard.tx3.getText();
				s4=ham.ard.tx4.getText();
				x=3;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="insert into adminregister values('"+s1+"','"+s2+"','"+s3+"','"+s4+"')";
				JOptionPane.showMessageDialog(am.ard.b1,"Admin Register Successful");
							
				st.executeUpdate(q);	
				System.out.println("Admin Registered");				
				
				if(x==1)
				{
					
				am.ard.tx1.setText("");
				am.ard.tx1.setText("First Name");
				
				am.ard.tx2.setText("");
				am.ard.tx2.setText("Last Name");
				
				am.ard.tx3.setText("");
				am.ard.tx3.setText("Email");
				
				am.ard.tx4.setText("");
				am.ard.tx4.setText("Password");
				
				am.ard.tx1.setForeground(Color.gray);	
				am.ard.tx2.setForeground(Color.gray);	
				am.ard.tx3.setForeground(Color.gray);	
				am.ard.tx4.setForeground(Color.gray);	
			}
				
				if(x==2)
				{
					
				pam.ard.tx1.setText("");
				pam.ard.tx1.setText("First Name");
				
				pam.ard.tx2.setText("");
				pam.ard.tx2.setText("Last Name");
				
				pam.ard.tx3.setText("");
				pam.ard.tx3.setText("Email");
				
				pam.ard.tx4.setText("");
				pam.ard.tx4.setText("Password");
				
				pam.ard.tx1.setForeground(Color.gray);	
				pam.ard.tx2.setForeground(Color.gray);	
				pam.ard.tx3.setForeground(Color.gray);	
				pam.ard.tx4.setForeground(Color.gray);	
			}				
			
			if(x==3)
				{
					
				ham.ard.tx1.setText("");
				ham.ard.tx1.setText("First Name");
				
				ham.ard.tx2.setText("");
				ham.ard.tx2.setText("Last Name");
				
				ham.ard.tx3.setText("");
				ham.ard.tx3.setText("Email");
				
				ham.ard.tx4.setText("");
				ham.ard.tx4.setText("Password");
				
				ham.ard.tx1.setForeground(Color.gray);	
				ham.ard.tx2.setForeground(Color.gray);	
				ham.ard.tx3.setForeground(Color.gray);	
				ham.ard.tx4.setForeground(Color.gray);	
			}
				con.close();
				
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.aaq.b2 || e.getSource()==pam.aaq.b2 || e.getSource()==ham.aaq.b2)
		{
			System.out.println("enter");
			int x=0;
			String s1="",s2="",s3="",s4="",s5="",s6="",s7="";
			if(e.getSource()==am.aaq.b2)
			{
				System.out.println("JAVA question addadd");
				s1=am.aaq.tx6.getText();
				s2=am.aaq.ta1.getText().trim();
				s3=am.aaq.tx5.getText();
				s4=am.aaq.tx1.getText();
				s5=am.aaq.tx2.getText();
				s6=am.aaq.tx3.getText();
				s7=am.aaq.tx4.getText();
				x=1;
			}
			else if(e.getSource()==pam.aaq.b2)
			{
				System.out.println("PHP question addadd");
				s1=pam.aaq.tx6.getText();
				s2=pam.aaq.ta1.getText().trim();
				s3=pam.aaq.tx5.getText();
				s4=pam.aaq.tx1.getText();
				s5=pam.aaq.tx2.getText();
				s6=pam.aaq.tx3.getText();
				s7=pam.aaq.tx4.getText();
				x=2;
			}
			else if(e.getSource()==ham.aaq.b2)
			{
				System.out.println("HTML question addadd");
				s1=ham.aaq.tx6.getText();
				s2=ham.aaq.ta1.getText().trim();
				s3=ham.aaq.tx5.getText();
				s4=ham.aaq.tx1.getText();
				s5=ham.aaq.tx2.getText();
				s6=ham.aaq.tx3.getText();
				s7=ham.aaq.tx4.getText();
				x=3;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
			if(x==1)
			{
				{
				String q="insert into questiontable values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
				
				JOptionPane.showMessageDialog(am.aaq.b1,"Question Add Successful");
				st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}	
				am.aaq.tx1.setText("");
				am.aaq.tx2.setText("");
				am.aaq.tx3.setText("");
				am.aaq.tx4.setText("");
				am.aaq.tx5.setText("");
				am.aaq.ta1.setText("");
			}
			if(x==2)
			{
				{
				String q="insert into pqt values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
				
				JOptionPane.showMessageDialog(pam.aaq.b1,"Question Add Successful");
				st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from pqt";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						pset++;
						pam.auq.tx6.setText(""+0);
					}
						pam.aaq.tx6.setText(""+(pset+1));
						pset=0;
				}	
				pam.aaq.tx1.setText("");
				pam.aaq.tx2.setText("");
				pam.aaq.tx3.setText("");
				pam.aaq.tx4.setText("");
				pam.aaq.tx5.setText("");
				pam.aaq.ta1.setText("");
			}
			if(x==3)
			{
				{
				String q="insert into hqt values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"')";
				
				JOptionPane.showMessageDialog(ham.aaq.b1,"Question Add Successful");
				st.executeUpdate(q);	
				}
				System.out.println("question_add");		

				{
					String q1="select * from hqt";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						hset++;
						ham.auq.tx6.setText(""+0);
					}
						ham.aaq.tx6.setText(""+(hset+1));
						hset=0;
				}	
				ham.aaq.tx1.setText("");
				ham.aaq.tx2.setText("");
				ham.aaq.tx3.setText("");
				ham.aaq.tx4.setText("");
				ham.aaq.tx5.setText("");
				ham.aaq.ta1.setText("");
			}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==am.auq.b2 || e.getSource()==pam.auq.b2 || e.getSource()==ham.auq.b2)
		{
			String s1="",s2="",s3="",s4="",s5="",s6="",s7="";
			int x=0;
			if(e.getSource()==am.auq.b2)
			{
				s1=am.auq.tx6.getText();
				s2=am.auq.ta1.getText().trim();
				s3=am.auq.tx5.getText();
				s4=am.auq.tx1.getText();
				s5=am.auq.tx2.getText();
				s6=am.auq.tx3.getText();
				s7=am.auq.tx4.getText();
				x=1;
			}
			if(e.getSource()==pam.auq.b2)
			{
				s1=pam.auq.tx6.getText();
				s2=pam.auq.ta1.getText().trim();
				s3=pam.auq.tx5.getText();
				s4=pam.auq.tx1.getText();
				s5=pam.auq.tx2.getText();
				s6=pam.auq.tx3.getText();
				s7=pam.auq.tx4.getText();
				x=2;
			}
			if(e.getSource()==ham.auq.b2)
			{
				s1=pam.auq.tx6.getText();
				s2=pam.auq.ta1.getText().trim();
				s3=pam.auq.tx5.getText();
				s4=pam.auq.tx1.getText();
				s5=pam.auq.tx2.getText();
				s6=pam.auq.tx3.getText();
				s7=pam.auq.tx4.getText();
				x=3;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				if(x==1)
				{
					
				
				
				Statement st=con.createStatement();
				{
				String q="update questiontable SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				JOptionPane.showMessageDialog(am.auq.b1,"Question Update Successful");
		
				}

				System.out.println("data update");
				am.aaq.tx1.setText("");
				am.aaq.tx2.setText("");
				am.aaq.tx3.setText("");
				am.aaq.tx4.setText("");
				am.aaq.tx5.setText("");
				am.aaq.ta1.setText("");
				con.close();
		}		
				
				if(x==2)
				{
					
				
				
				Statement st=con.createStatement();
				{
				String q="update pqt SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				JOptionPane.showMessageDialog(pam.auq.b1,"Question Update Successful");
		
				}

				System.out.println("data update");
				pam.aaq.tx1.setText("");
				pam.aaq.tx2.setText("");
				pam.aaq.tx3.setText("");
				pam.aaq.tx4.setText("");
				pam.aaq.tx5.setText("");
				pam.aaq.ta1.setText("");
				con.close();
		}		
				if(x==3)
				{
					Statement st=con.createStatement();
				{
				String q="update hqt SET question='"+s2+"',answer='"+s3+"',o1='"+s4+"',o2='"+s5+"',o3='"+s6+"',o4='"+s7+"' where sno='"+s1+"'";
				st.executeUpdate(q);	
				JOptionPane.showMessageDialog(ham.auq.b1,"Question Update Successful");
		
				}

				System.out.println("data update");
				ham.aaq.tx1.setText("");
				ham.aaq.tx2.setText("");
				ham.aaq.tx3.setText("");
				ham.aaq.tx4.setText("");
				ham.aaq.tx5.setText("");
				ham.aaq.ta1.setText("");
				con.close();
		}
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
		if(e.getSource()==ald.b1)
		{
			String s1=ald.tx1.getText();
			String s2=ald.tx2.getText();
			String s3=ald.tx3.getText();
			String s4=ald.tx4.getText();
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st=con.createStatement();
				
				String q="select * from adminregister";				
				
				{
					ResultSet rs=st.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)) && s2.equals(rs.getString(2)) && s3.equals(rs.getString(3)) && s4.equals(rs.getString(4)))
						{
							cr.show(cn,"adminmenu");	
							i=1;
							System.out.println("welcome");
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"Please use correct id and password");
					}
				}

				{
					String q1="select * from questiontable";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						set++;
						am.auq.tx6.setText(""+0);
					}
						am.aaq.tx6.setText(""+(set+1));
						set=0;
				}
				
				{
					String q1="select * from pqt";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						pset++;
						pam.auq.tx6.setText(""+0);
					}
						pam.aaq.tx6.setText(""+(pset+1));
						pset=0;
				}
				
				{
					String q1="select * from hqt";
					ResultSet rs=st.executeQuery(q1);
					while(rs.next())
					{
						hset++;
						ham.auq.tx6.setText(""+0);
					}
						ham.aaq.tx6.setText(""+(hset+1));
						hset=0;
				}
											
				ald.tx1.setText("");
				ald.tx1.setText("First Name");
				
				ald.tx2.setText("");
				ald.tx2.setText("Last Name");
				
				ald.tx3.setText("");
				ald.tx3.setText("Email");
				
				ald.tx4.setText("");
				ald.tx4.setText("Password");
				
				ald.tx1.setForeground(Color.gray);	
				ald.tx2.setForeground(Color.gray);	
				ald.tx3.setForeground(Color.gray);	
				ald.tx4.setForeground(Color.gray);	

					
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println("aaa");	
			}
		}
		
		if(e.getSource()==am.adq.b1 || e.getSource()==pam.adq.b1 || e.getSource()==ham.adq.b1)
		{
			int x=0;
			String s1="",s2="",s3="";
			if(e.getSource()==am.adq.b1)
			{
				s1=am.adq.tx1.getText();
				x=1;
			}
			else if(e.getSource()==pam.adq.b1)
			{
				s1=pam.adq.tx1.getText();
				x=2;
			}
			else if(e.getSource()==ham.adq.b1)
			{
				s1=ham.adq.tx1.getText();
				x=3;
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				
		if(x==1)
		{
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from questiontable";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from questiontable where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
							JOptionPane.showMessageDialog(am.adq.b1,"Delete Question");
							i=1;
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(am.adq.b1,"invalid sno.");
					}
				}	
				String q1="select * from questiontable";				
				
				{
					int o=0;
					ResultSet rs1=st2.executeQuery(q1);	
					while(rs1.next())
					{
						++o;
					}
					am.aaq.tx6.setText(""+ ++o);
				}
				
				am.adq.tx1.setText("");
			}
							
		if(x==2)
		{
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from pqt";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from pqt where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
							JOptionPane.showMessageDialog(pam.adq.b1,"Delete Question");
							i=1;
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(pam.adq.b1,"invalid sno.");
					}
				}	
				String q1="select * from pqt";				
				
				{
					int o=0;
					ResultSet rs1=st2.executeQuery(q1);	
					while(rs1.next())
					{
						++o;
					}
					pam.aaq.tx6.setText(""+ ++o);
				}
				
				pam.adq.tx1.setText("");
			}
						
		if(x==3)
		{
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String q="select * from hqt";				
				
				{
					ResultSet rs=st1.executeQuery(q);	
					while(rs.next())
					{
						if(s1.equals(rs.getString(1)))
						{
							String q1="delete from hqt where sno='"+s1+"'";
							st2.executeUpdate(q1);
							System.out.println("data delete");
							JOptionPane.showMessageDialog(ham.adq.b1,"Delete Question");
							i=1;
						}
					}
					if(i==0)
					{
						JOptionPane.showMessageDialog(ham.adq.b1,"invalid sno.");
					}
				}	
				String q1="select * from hqt";				
				
				{
					int o=0;
					ResultSet rs1=st2.executeQuery(q1);	
					while(rs1.next())
					{
						++o;
					}
					ham.aaq.tx6.setText(""+ ++o);
				}
				
				ham.adq.tx1.setText("");
			}
				
			con.close();
		}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}

		if(e.getSource()==jp.b1 && sa<9)
		{
			
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			else if(jp.rb2.isSelected())
			{
				coll[sa]=jp.rb2.getLabel();
			}
			else if(jp.rb3.isSelected())
			{
				coll[sa]=jp.rb3.getLabel();
				
			}
			else if(jp.rb4.isSelected())
			{
				coll[sa]=jp.rb4.getLabel();
			}
			if(coll[sa]!=null)
			{
				System.out.println("khali nhi h");
				jp.bg.clearSelection();					
			}
			else
			{
				System.out.println("khali h");
			}
			++sa;
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from questiontable";
				if(xx < in){
					xx+=1;
					ResultSet rs=st1.executeQuery(abhi);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							jp.tx1.setText(rs.getString(2));
							jp.rb1.setLabel(rs.getString(4));
							jp.rb2.setLabel(rs.getString(5));
							jp.rb3.setLabel(rs.getString(6));
							jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("n="+xx);
					
					if(xx==9)
					{
						if(jp.rb1.getLabel().equals(coll[8]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[8]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[8]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[8]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(jp.rb1.getLabel().equals(coll[7]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[7]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[7]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[7]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==7)
					{
						if(jp.rb1.getLabel().equals(coll[6]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[6]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[6]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[6]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(jp.rb1.getLabel().equals(coll[5]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[5]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[5]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[5]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(jp.rb1.getLabel().equals(coll[4]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[4]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[4]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[4]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(jp.rb1.getLabel().equals(coll[3]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[3]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[3]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[3]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(jp.rb1.getLabel().equals(coll[2]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[2]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[2]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[2]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
						if(jp.rb1.getLabel().equals(coll[1]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[1]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[1]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[1]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(jp.rb1.getLabel().equals(coll[0]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[0]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[0]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[0]) )
						{
							jp.rb4.setSelected(true);
						}
					}
				
					
				}
				System.out.println("sa="+sa);
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		if(e.getSource()==jp.b2)
		{
			sa=9;
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			else if(jp.rb2.isSelected())
			{
				coll[sa]=jp.rb2.getLabel();
			}
			else if(jp.rb3.isSelected())
			{
				coll[sa]=jp.rb3.getLabel();
			}
			else if(jp.rb4.isSelected())
			{
				coll[sa]=jp.rb4.getLabel();
			}
			
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from questiontable";
				int x=0,kk=0;
				
				ResultSet rs=st1.executeQuery(abhi);
				while(rs.next())
				{
						if(coll[x].equals(rs.getString(3)))
						{
							rd.tx[x].setText("Right");
							rd.tx[x].setBackground(Color.GREEN);
							rd.tx[x].setForeground(Color.WHITE);
							kk+=10;	
						}
						else
						{
							rd.tx[x].setText("Wrong");	
							rd.tx[x].setBackground(Color.RED);
							rd.tx[x].setForeground(Color.WHITE);							
						}
						if(x<9)
						{
							x++;
						}
						rd.tx1.setText(""+kk+"%");
				}
				cr.show(cn,"result");
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);
			}
				
		}
		
		
		if(e.getSource()==jp.b3 && sa>0)
		{
			if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			
			else if(jp.rb1.isSelected())
			{
				coll[sa]=jp.rb1.getLabel();
			}
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				String a="jdbc:mysql://localhost:3306/online?useSSL=false";
				String b="root";
				String c="root";
				
				Connection con=DriverManager.getConnection(a,b,c);
				
				Statement st1=con.createStatement();
				Statement st2=con.createStatement();
				
				String abhi="select * from questiontable";
				
				if(xx>1){
					xx=xx-1;	
					ResultSet rs=st1.executeQuery(abhi);	
					while(rs.next() && yy<=xx)
					{
						if(yy<xx)
						{
							
						}
						else
						{
							jp.tx1.setText(rs.getString(2));
							jp.rb1.setLabel(rs.getString(4));
							jp.rb2.setLabel(rs.getString(5));
							jp.rb3.setLabel(rs.getString(6));
							jp.rb4.setLabel(rs.getString(7));
						}
						yy++;
					}
					yy=1;
					if(i==0)
					{
						JOptionPane.showMessageDialog(ald.b1,"invalid sno.");
					}
					System.out.println("p="+xx);
				}
					--sa;
				System.out.println("sa="+sa);
					if(xx==9)
					{
						if(jp.rb1.getLabel().equals(coll[8]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[8]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[8]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[8]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==8)
					{
						if(jp.rb1.getLabel().equals(coll[7]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[7]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[7]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[7]) )
						{
							jp.rb4.setSelected(true);
						} 
					}
					
					if(xx==7)
					{
						if(jp.rb1.getLabel().equals(coll[6]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[6]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[6]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[6]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==6)
					{
						if(jp.rb1.getLabel().equals(coll[5]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[5]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[5]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[5]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==5)
					{
						if(jp.rb1.getLabel().equals(coll[4]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[4]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[4]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[4]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==4)
					{
						if(jp.rb1.getLabel().equals(coll[3]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[3]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[3]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[3]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==3)
					{
						if(jp.rb1.getLabel().equals(coll[2]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[2]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[2]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[2]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==2)
					{
						if(jp.rb1.getLabel().equals(coll[1]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[1]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[1]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[1]) )
						{
							jp.rb4.setSelected(true);
						}
					}
					
					if(xx==1)
					{
						if(jp.rb1.getLabel().equals(coll[0]) )
						{
							jp.rb1.setSelected(true);
						}
						else if(jp.rb2.getLabel().equals(coll[0]) )
						{
							jp.rb2.setSelected(true);
						}
						else if(jp.rb3.getLabel().equals(coll[0]) )
						{
							jp.rb3.setSelected(true);
						}
						else if(jp.rb4.getLabel().equals(coll[0]) )
						{
							jp.rb4.setSelected(true);
						}
					}
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);	
			}
		}
		
	}
}
class JPDemo extends JPanel 
{
	
	JTextArea tx1,tx2;
	ButtonGroup bg;
	int h=0;
	JRadioButton rb1,rb2,rb3,rb4;
	JButton b1,b2,b3;
	JLabel l1,l2,l3;
	int z=1,h1=1;
	Timer t;
	Font f=new Font("",Font.BOLD,25);
	ImageIcon ii;
	String s1;
	Image i;
	JPDemo(FDemo f1)
	{
		setLayout(null);
		
		bg=new ButtonGroup();
		
		tx1=new JTextArea();
		tx1.setFont(f);
		tx1.setBounds(150,200,760,30);
		add(tx1);
		
		tx2=new JTextArea();
		tx2.setFont(f);
		tx2.setBounds(20,150,70,30);
		add(tx2);
		
		l2=new JLabel("Time");
		l2.setFont(f);
		l2.setBounds(20,120,200,20);
		add(l2);
		
		rb1=new JRadioButton("option1");
		bg.add(rb1);
		rb1.setFont(f);
		rb1.setBounds(150,300,200,50);
		add(rb1);
		
		rb2=new JRadioButton("option2");
		rb2.setFont(f);
		bg.add(rb2);
		rb2.setBounds(150,350,200,50);
		add(rb2);
		
		rb3=new JRadioButton("option3");
		rb3.setFont(f);
		bg.add(rb3);
		rb3.setBounds(150,400,200,50);
		add(rb3);
		
		rb4=new JRadioButton("option4");
		rb4.setBounds(150,450,200,50);
		rb4.setFont(f);
		bg.add(rb4);
		add(rb4);
		
		b1=new JButton("Next");
		b1.setFont(f);
		b1.setBounds(600,500,150,30);
		add(b1);
		
		b3=new JButton("Privious");
		b3.setFont(f);
		b3.setBounds(450,500,150,30);
		add(b3);
		
		b2=new JButton("Submit");
		b2.setFont(f);
		b2.setBounds(750,500,150,30);
		add(b2);
		
		b1.addActionListener(f1);
		b2.addActionListener(f1);
		b3.addActionListener(f1);
		
	}
}
class ResultDemo extends JPanel
{
	JTextField tx[]=new JTextField[10];
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
	JTextField tx1,tx2,tx3,tx4,tx5,tx6,tx7,tx8,tx9,tx10,tx11;
	Font f=new Font("",Font.BOLD,25);
	int x=120,y=150,w=100,h=50;
	
	ResultDemo(FDemo f1)
	{
		setLayout(null);
		
		
		l11=new JLabel("Percentage %");
		l11.setBounds(420,50,250,52);
		l11.setFont(f);
		add(l11);	
		
		tx1=new JTextField("");
		tx1.setBounds(420,100,200,50);
		tx1.setFont(f);
		add(tx1);
		
		for(int i=0;i<=9;i++)
		{
			tx[i]=new JTextField();
			tx[i].setBounds(x,y,w,h);
			tx[i].setForeground(Color.BLACK);
			tx[i].setFont(f);
			add(tx[i]);
			y+=50;
		}
		
		l1=new JLabel("Q.1");
		l1.setBounds(50,150,100,52);
		l1.setFont(f);
		add(l1);	
		
		l2=new JLabel("Q.2");
		l2.setBounds(50,200,100,52);
		l2.setFont(f);
		add(l2);
		
		l3=new JLabel("Q.3");
		l3.setBounds(50,250,100,52);
		l3.setFont(f);
		add(l3);
		
		l4=new JLabel("Q.4");
		l4.setBounds(50,300,100,52);
		l4.setFont(f);
		add(l4);
		
		l5=new JLabel("Q.5");
		l5.setBounds(50,350,100,52);
		l5.setFont(f);
		add(l5);
		
		l6=new JLabel("Q.6");
		l6.setBounds(50,400,100,52);
		l6.setFont(f);
		add(l6);
		
		l7=new JLabel("Q.7");
		l7.setBounds(50,450,100,52);
		l7.setFont(f);
		add(l7);	
		
		l8=new JLabel("Q.8");
		l8.setBounds(50,500,100,52);
		l8.setFont(f);
		add(l8);
		
		l9=new JLabel("Q.9");
		l9.setBounds(50,550,100,52);
		l9.setFont(f);
		add(l9);	
		
		l10=new JLabel("Q.10");
		l10.setBounds(50,600,100,52);
		l10.setFont(f);
		add(l10);	
	}

}
class online
{
	public static void main(String... ar)
	{
		FDemo f =new FDemo();
		f.setVisible(true);
		f.setBounds(200,50,1300,900);
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	}
}