import javax.swing.*;
import java.awt.*;
class AdminAddSubject extends JPanel
{
	JButton b1,b2;
	JTextField tx1;
	JComboBox cb1;
	Font f=new Font("",Font.BOLD,20);
	AdminAddSubject(FDemo f1)
	{
		setLayout(null);
		
		tx1=new JTextField();
		tx1.setBounds(400,200,100,50);
		tx1.setFont(f);
		add(tx1);
		
		cb1=new JComboBox();
		cb1.setBounds(600,200,100,50);
		cb1.setFont(f);
		add(cb1);
		
		
		b1=new JButton("ADD Subject");
		b1.setBounds(200,300,250,50);
		b1.setFont(f);
		add(b1);
		
		b1.addActionListener(f1);
		
		b2=new JButton("DELETE Subject");
		b2.setBounds(455,300,250,50);
		b2.setFont(f);
		add(b2);

		b2.addActionListener(f1);
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(100,100,700,400,100,100);
	}
}