import javax.swing.*;
import java.awt.*;
class AdminLogout extends JPanel
{
	Font f=new Font("",Font.BOLD,15);
	JButton b1;
	AdminLogout(FDemo f1)
	{
		setLayout(null);

		b1=new JButton("Logout");
		b1.setBounds(500,300,200,50);
		add(b1);

		b1.addActionListener(f1);
		
		b1.setFont(f);		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(new Color(207,207,207));
		setForeground(new Color(134,181,223));		
		g.fillRoundRect(450,250,300,150,50,50);
	}
}