import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.*;
class IntroPanel extends JPanel
{
	JLabel l1,l2,l3,l4;
	JButton b1;
	Font f1=new Font("",Font.BOLD,60);
	Font f2=new Font("",Font.BOLD,30);
	Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
	IntroPanel(FDemo f)
	{
		setLayout(null);
		setBackground(Color.cyan);
		l1=new JLabel("Created By Softwaves Technologies");
		l1.setForeground(new Color(129,163,220));
		l1.setBounds(550,10,1200,100);
		l1.setFont(f1);
		add(l1);
		l2=new JLabel("Devloped By : Abhishek Pal");
		l2.setBounds(10,200,800,100);
		l2.setForeground(Color.WHITE);
		l2.setFont(f2);
		add(l2);
		
		l3=new JLabel("Instructions");
		l3.setBounds(1200,200,200,50);
		l3.setForeground(Color.WHITE);
		l3.setFont(f2);
		add(l3);
		
		l4=new JLabel("Click Below");
		l4.setBounds(730,400,200,50);
		l4.setFont(f2);
		l4.setForeground(Color.WHITE);
		add(l4);
		
		b1=new JButton("Next");
		b1.setBounds(740,500,150,50);
		b1.setFont(f2);
		b1.setBackground(Color.BLACK);
		b1.setForeground(Color.WHITE);
		b1.setBorder(null);
		b1.setContentAreaFilled(false);
		add(b1);
		b1.addActionListener(f);
	}
	public void paintComponent(Graphics g)
	{
		// g.setColor(Color.BLUE);
		g.drawImage(new ImageIcon("k1.jpg").getImage(),0,0,d.width,d.height,this);
		g.drawImage(new ImageIcon("swt.jpg").getImage(),0,0,500,200,this);
	}
}